package org.bouncycastle.asn1.x509;


import org.bouncycastle.asn1.ASN1Object;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Primitive;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.util.Arrays;

/**
 * The DigestInfo object.
 * <pre>
 * DigestInfo::=SEQUENCE{
 *          digestAlgorithm  AlgorithmIdentifier,
 *          digest OCTET STRING }
 * </pre>
 */
public class DigestInfo
    extends ASN1Object
{
    private byte[]                  digest;
    private AlgorithmIdentifier     algId;

    public static DigestInfo getInstance(
        ASN1TaggedObject obj,
        boolean          explicit)
    {
        return getInstance(ASN1Sequence.getInstance(obj, explicit));
    }

    public static DigestInfo getInstance(
        Object  obj)
    {
        if (obj instanceof DigestInfo)
        {
            return (DigestInfo)obj;
        }
        else if (obj != null)
        {
            return new DigestInfo(ASN1Sequence.getInstance(obj));
        }

        return null;
    }

    public DigestInfo(
        AlgorithmIdentifier  algId,
        byte[]               digest)
    {
        this.digest = Arrays.clone(digest);
        this.algId = algId;
    }

    public DigestInfo(
        ASN1Sequence  obj)
    {
        if (obj.size() != 2)
        {
            throw new IllegalArgumentException("Bad sequence size: " + obj.size());
        }

        algId = AlgorithmIdentifier.getInstance(obj.getObjectAt(0));
        digest = ASN1OctetString.getInstance(obj.getObjectAt(1)).getOctets();
    }

    public AlgorithmIdentifier getAlgorithmId()
    {
        return algId;
    }

    public byte[] getDigest()
    {
        return Arrays.clone(digest);
    }

    public ASN1Primitive toASN1Primitive()
    {
        return new DERSequence(algId, new DEROctetString(digest));
    }
}
