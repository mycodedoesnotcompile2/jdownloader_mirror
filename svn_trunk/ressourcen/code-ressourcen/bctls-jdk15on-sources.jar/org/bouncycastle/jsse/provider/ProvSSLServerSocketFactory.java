package org.bouncycastle.jsse.provider;

import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;

import javax.net.ssl.SSLServerSocketFactory;

class ProvSSLServerSocketFactory
    extends SSLServerSocketFactory
{
    protected final ContextData contextData;

    ProvSSLServerSocketFactory(ContextData contextData)
    {
        super();

        this.contextData = contextData;
    }

     
    public ServerSocket createServerSocket() throws IOException
    {
        return new ProvSSLServerSocket(contextData);
    }

     
    public ServerSocket createServerSocket(int port) throws IOException
    {
        return new ProvSSLServerSocket(contextData, port);
    }

     
    public ServerSocket createServerSocket(int port, int backlog) throws IOException
    {
        return new ProvSSLServerSocket(contextData, port, backlog);
    }

     
    public ServerSocket createServerSocket(int port, int backlog, InetAddress ifAddress) throws IOException
    {
        return new ProvSSLServerSocket(contextData, port, backlog, ifAddress);
    }

     
    public String[] getDefaultCipherSuites()
    {
        return contextData.getDefaultCipherSuites(false);
    }

     
    public String[] getSupportedCipherSuites()
    {
        return contextData.getSupportedCipherSuites();
    }
}
