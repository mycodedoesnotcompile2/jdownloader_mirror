package org.bouncycastle.jsse.provider;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;

import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLServerSocket;

import org.bouncycastle.jsse.BCSSLParameters;
import org.bouncycastle.jsse.BCSSLServerSocket;

class ProvSSLServerSocket
    extends SSLServerSocket
    implements BCSSLServerSocket
{
    protected final ContextData contextData;
    protected final ProvSSLParameters sslParameters;

    protected boolean enableSessionCreation = true;
    protected boolean useClientMode = false;

    protected ProvSSLServerSocket(ContextData contextData)
        throws IOException
    {
        super();

        this.contextData = contextData;
        this.sslParameters = contextData.getDefaultSSLParameters(useClientMode);
    }

    protected ProvSSLServerSocket(ContextData contextData, int port)
        throws IOException
    {
        super(port);

        this.contextData = contextData;
        this.sslParameters = contextData.getDefaultSSLParameters(useClientMode);
    }

    protected ProvSSLServerSocket(ContextData contextData, int port, int backlog)
        throws IOException
    {
        super(port, backlog);

        this.contextData = contextData;
        this.sslParameters = contextData.getDefaultSSLParameters(useClientMode);
    }

    protected ProvSSLServerSocket(ContextData contextData, int port, int backlog, InetAddress address)
        throws IOException
    {
        super(port, backlog, address);

        this.contextData = contextData;
        this.sslParameters = contextData.getDefaultSSLParameters(useClientMode);
    }

     
    public synchronized Socket accept() throws IOException
    {
        ProvSSLSocketDirect socket = SSLSocketUtil.create(contextData, enableSessionCreation, useClientMode,
            sslParameters.copy());

        implAccept(socket);
        socket.notifyConnected();

        return socket;
    }

     
    public synchronized boolean getEnableSessionCreation()
    {
        return enableSessionCreation;
    }

     
    public synchronized String[] getEnabledCipherSuites()
    {
        return sslParameters.getCipherSuites();
    }

     
    public synchronized String[] getEnabledProtocols()
    {
        return sslParameters.getProtocols();
    }

     
    public synchronized boolean getNeedClientAuth()
    {
        return sslParameters.getNeedClientAuth();
    }

    public synchronized BCSSLParameters getParameters()
    {
        return SSLParametersUtil.getParameters(sslParameters);
    }

     
    public synchronized SSLParameters getSSLParameters()
    {
        return SSLParametersUtil.getSSLParameters(sslParameters);
    }

     
    public synchronized String[] getSupportedCipherSuites()
    {
        return contextData.getSupportedCipherSuites();
    }

     
    public synchronized String[] getSupportedProtocols()
    {
        return contextData.getSupportedProtocols();
    }

     
    public synchronized boolean getUseClientMode()
    {
        return useClientMode;
    }

     
    public synchronized boolean getWantClientAuth()
    {
        return sslParameters.getWantClientAuth();
    }

     
    public synchronized void setEnableSessionCreation(boolean flag)
    {
        this.enableSessionCreation = flag;
    }

     
    public synchronized void setEnabledCipherSuites(String[] suites)
    {
        sslParameters.setCipherSuites(suites);
    }

     
    public synchronized void setEnabledProtocols(String[] protocols)
    {
        sslParameters.setProtocols(protocols);
    }

     
    public synchronized void setNeedClientAuth(boolean need)
    {
        sslParameters.setNeedClientAuth(need);
    }

    public synchronized void setParameters(BCSSLParameters parameters)
    {
        SSLParametersUtil.setParameters(this.sslParameters, parameters);
    }

     
    public synchronized void setSSLParameters(SSLParameters sslParameters)
    {
        SSLParametersUtil.setSSLParameters(this.sslParameters, sslParameters);
    }

     
    public synchronized void setUseClientMode(boolean useClientMode)
    {
        if (this.useClientMode != useClientMode)
        {
            contextData.updateDefaultSSLParameters(sslParameters, useClientMode);

            this.useClientMode = useClientMode;
        }
    }

     
    public synchronized void setWantClientAuth(boolean want)
    {
        sslParameters.setWantClientAuth(want);
    }
}
