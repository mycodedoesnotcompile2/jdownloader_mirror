package org.bouncycastle.tls;

import java.io.IOException;
import java.io.InterruptedIOException;

public class DTLSTransport
    implements DatagramTransport
{
    private final DTLSRecordLayer recordLayer;

    DTLSTransport(DTLSRecordLayer recordLayer)
    {
        this.recordLayer = recordLayer;
    }

    /**
     * Package-private access to the record layer behind this transport. There is no application-facing
     * contract here, and none is implied: this widens no published API, and nothing outside this package can
     * reach it. It exists because the package-private DTLS 1.3 machinery - a post-handshake key update, for
     * one - has no application-facing entry point, any more than {@link TlsProtocol} has one for TLS.
     */
    DTLSRecordLayer getRecordLayer()
    {
        return recordLayer;
    }

    public int getReceiveLimit()
        throws IOException
    {
        return recordLayer.getReceiveLimit();
    }

    public int getSendLimit()
        throws IOException
    {
        return recordLayer.getSendLimit();
    }

    public int receive(byte[] buf, int off, int len, int waitMillis)
        throws IOException
    {
        return receive(buf, off, len, waitMillis, null);
    }

    /**
     * A waitMillis of zero is interpreted as an infinite timeout.
     */
    public int receive(byte[] buf, int off, int len, int waitMillis, DTLSRecordCallback recordCallback)    
        throws IOException
    {
        if (null == buf)
        {
            throw new NullPointerException("'buf' cannot be null");
        }
        if (off < 0 || off >= buf.length)
        {
            throw new IllegalArgumentException("'off' is an invalid offset: " + off);
        }
        if (len < 0 || len > buf.length - off)
        {
            throw new IllegalArgumentException("'len' is an invalid length: " + len);
        }
        if (waitMillis < 0)
        {
            throw new IllegalArgumentException("'waitMillis' cannot be negative");
        }

        try
        {
            return recordLayer.receive(buf, off, len, waitMillis, recordCallback);
        }
        catch (TlsFatalAlertReceived fatalAlertReceived)
        {
//            assert recordLayer.isFailed();
            throw fatalAlertReceived;
        }
        catch (TlsFatalAlert fatalAlert)
        {
            recordLayer.fail(fatalAlert.getAlertDescription());
            throw fatalAlert;
        }
        catch (InterruptedIOException e)
        {
            throw e;
        }
        catch (IOException e)
        {
            recordLayer.fail(AlertDescription.internal_error);
            throw e;
        }
        catch (RuntimeException e)
        {
            recordLayer.fail(AlertDescription.internal_error);
            throw new TlsFatalAlert(AlertDescription.internal_error, e);
        }
    }

    public int receivePending(byte[] buf, int off, int len)
        throws IOException
    {
        return receivePending(buf, off, len, null);
    }

    public int receivePending(byte[] buf, int off, int len, DTLSRecordCallback recordCallback)    
        throws IOException
    {
        if (null == buf)
        {
            throw new NullPointerException("'buf' cannot be null");
        }
        if (off < 0 || off >= buf.length)
        {
            throw new IllegalArgumentException("'off' is an invalid offset: " + off);
        }
        if (len < 0 || len > buf.length - off)
        {
            throw new IllegalArgumentException("'len' is an invalid length: " + len);
        }

        try
        {
            return recordLayer.receivePending(buf, off, len, recordCallback);
        }
        catch (TlsFatalAlertReceived fatalAlertReceived)
        {
//            assert recordLayer.isFailed();
            throw fatalAlertReceived;
        }
        catch (TlsFatalAlert fatalAlert)
        {
            recordLayer.fail(fatalAlert.getAlertDescription());
            throw fatalAlert;
        }
        catch (InterruptedIOException e)
        {
            throw e;
        }
        catch (IOException e)
        {
            recordLayer.fail(AlertDescription.internal_error);
            throw e;
        }
        catch (RuntimeException e)
        {
            recordLayer.fail(AlertDescription.internal_error);
            throw new TlsFatalAlert(AlertDescription.internal_error, e);
        }
    }

    public void send(byte[] buf, int off, int len)
        throws IOException
    {
        if (null == buf)
        {
            throw new NullPointerException("'buf' cannot be null");
        }
        if (off < 0 || off >= buf.length)
        {
            throw new IllegalArgumentException("'off' is an invalid offset: " + off);
        }
        if (len < 0 || len > buf.length - off)
        {
            throw new IllegalArgumentException("'len' is an invalid length: " + len);
        }

        try
        {
            recordLayer.send(buf, off, len);
        }
        catch (TlsFatalAlert fatalAlert)
        {
            recordLayer.fail(fatalAlert.getAlertDescription());
            throw fatalAlert;
        }
        catch (InterruptedIOException e)
        {
            throw e;
        }
        catch (IOException e)
        {
            recordLayer.fail(AlertDescription.internal_error);
            throw e;
        }
        catch (RuntimeException e)
        {
            recordLayer.fail(AlertDescription.internal_error);
            throw new TlsFatalAlert(AlertDescription.internal_error, e);
        }
    }

    public void close()
        throws IOException
    {
        recordLayer.close();
    }
}
