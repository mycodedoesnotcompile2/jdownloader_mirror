package org.bouncycastle.tls;

/**
 * RFC 2246 6.2.1
 */
public class ContentType
{
    public static final short change_cipher_spec = 20;
    public static final short alert = 21;
    public static final short handshake = 22;
    public static final short application_data = 23;
    public static final short heartbeat = 24;
    public static final short tls12_cid = 25;
    /** RFC 9147 7.1 */
    public static final short ack = 26;

    public static String getName(short contentType)
    {
        switch (contentType)
        {
        case alert:
            return "alert";
        case application_data:
            return "application_data";
        case change_cipher_spec:
            return "change_cipher_spec";
        case handshake:
            return "handshake";
        case heartbeat:
            return "heartbeat";
        case tls12_cid:
            return "tls12_cid";
        case ack:
            return "ack";
        default:
            return "UNKNOWN";
        }
    }

    public static String getText(short contentType)
    {
        return getName(contentType) + "(" + contentType + ")";
    }
}
