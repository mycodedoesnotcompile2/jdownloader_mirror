package org.bouncycastle.tls;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

/**
 * RFC 9147 7.2. Tracks which record carried which handshake fragment of the current outbound flight, so
 * that an ACK retires exactly the fragments it covers and a retransmission resends only what is left.
 * <p>
 * A fragment may be registered more than once, under a different record number each time it is sent. It
 * is acknowledged as soon as any one of those records is acknowledged.
 * </p>
 */
class DTLS13FlightTracker
{
    /** One handshake fragment of the current outbound flight. */
    static final class Fragment
    {
        private final int messageSeq;
        private final int fragmentOffset;
        private final int fragmentLength;

        /*
         * RFC 9147 5.8.1. The epoch the fragment was first sent at, which is the epoch it must be retransmitted
         * at: a DTLS 1.3 flight straddles an epoch change, and once the handshake completes the write epoch has
         * moved on past the keys a peer that is still retransmitting can read. Negative until a record number
         * is registered, which means nothing was actually written.
         */
        private int epoch = -1;

        boolean acknowledged = false;

        Fragment(int messageSeq, int fragmentOffset, int fragmentLength)
        {
            this.messageSeq = messageSeq;
            this.fragmentOffset = fragmentOffset;
            this.fragmentLength = fragmentLength;
        }

        int getEpoch()
        {
            return epoch;
        }

        int getMessageSeq()
        {
            return messageSeq;
        }

        int getFragmentOffset()
        {
            return fragmentOffset;
        }

        int getFragmentLength()
        {
            return fragmentLength;
        }

        private String key()
        {
            return messageSeq + ":" + fragmentOffset + ":" + fragmentLength;
        }
    }

    // record number -> Fragment
    private Hashtable carriers = new Hashtable();
    // fragment key -> Fragment, so the same fragment sent twice is one entry
    private Hashtable fragments = new Hashtable();
    // fragments in registration order, for deterministic retransmission
    private Vector order = new Vector();

    void reset()
    {
        carriers = new Hashtable();
        fragments = new Hashtable();
        order = new Vector();
    }

    void register(DTLSRecordNumber recordNumber, int messageSeq, int fragmentOffset, int fragmentLength)
    {
        Fragment fragment = new Fragment(messageSeq, fragmentOffset, fragmentLength);
        String key = fragment.key();

        Fragment existing = (Fragment)fragments.get(key);
        if (null == existing)
        {
            fragments.put(key, fragment);
            order.addElement(fragment);
            existing = fragment;
        }

        if (null != recordNumber)
        {
            carriers.put(recordNumber, existing);

            if (existing.epoch < 0)
            {
                existing.epoch = (int)recordNumber.getEpoch();
            }
        }
    }

    void acknowledge(Vector recordNumbers)
    {
        for (int i = 0; i < recordNumbers.size(); ++i)
        {
            Fragment fragment = (Fragment)carriers.get(recordNumbers.elementAt(i));
            if (null != fragment)
            {
                fragment.acknowledged = true;
            }
        }
    }

    boolean isEmpty()
    {
        return order.isEmpty();
    }

    /**
     * @return true if any registered fragment has not been acknowledged; false when every one has been, and
     *         so also when nothing was registered.
     */
    boolean hasOutstanding()
    {
        Enumeration e = order.elements();
        while (e.hasMoreElements())
        {
            if (!((Fragment)e.nextElement()).acknowledged)
            {
                return true;
            }
        }
        return false;
    }

    /**
     * @return the fragments not yet acknowledged, in the order they were first registered.
     */
    Vector getOutstanding()
    {
        Vector outstanding = new Vector();

        Enumeration e = order.elements();
        while (e.hasMoreElements())
        {
            Fragment fragment = (Fragment)e.nextElement();
            if (!fragment.acknowledged)
            {
                outstanding.addElement(fragment);
            }
        }

        return outstanding;
    }
}
