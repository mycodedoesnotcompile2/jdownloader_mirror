package org.bouncycastle.cms.jcajce;

import java.io.IOException;
import java.security.AlgorithmParameters;
import java.security.GeneralSecurityException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1Integer;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.cms.CMSObjectIdentifiers;
import org.bouncycastle.asn1.cms.IssuerAndSerialNumber;
import org.bouncycastle.asn1.cryptopro.CryptoProObjectIdentifiers;
import org.bouncycastle.asn1.iso.ISOIECObjectIdentifiers;
import org.bouncycastle.asn1.oiw.OIWObjectIdentifiers;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.Certificate;
import org.bouncycastle.asn1.x509.Extension;
import org.bouncycastle.cms.CMSAlgorithm;
import org.bouncycastle.cms.CMSException;
import org.bouncycastle.jcajce.util.AlgorithmParametersUtils;
import org.bouncycastle.jcajce.util.AnnotatedPrivateKey;
import org.bouncycastle.jcajce.util.JcaJceHelper;
import org.bouncycastle.operator.GenericKey;
import org.bouncycastle.operator.OperatorCreationException;

class CMSUtils
{
    /**
     * Return the content-encryption algorithm an EncryptedContentInfo actually names, resolving the
     * RFC 9709 id-alg-cek-hkdf-sha256 wrapper to the AlgorithmIdentifier carried in its parameters.
     * <p>
     * org.bouncycastle.cms.CMSUtils carries the same method for the lightweight side of the package,
     * which cannot see this one - keep the two in step.
     *
     * @param contentAlgorithm the content-encryption AlgorithmIdentifier taken from the message.
     * @return the algorithm the content is encrypted under.
     * @throws CMSException if the key derivation carries no readable content-encryption algorithm.
     */
    static AlgorithmIdentifier getContentEncryptionAlgorithm(AlgorithmIdentifier contentAlgorithm)
        throws CMSException
    {
        if (!CMSObjectIdentifiers.id_alg_cek_hkdf_sha256.equals(contentAlgorithm.getAlgorithm()))
        {
            return contentAlgorithm;
        }

        ASN1Encodable params = contentAlgorithm.getParameters();

        if (params == null)
        {
            throw new CMSException("RFC 9709 key derivation names no content-encryption algorithm");
        }

        try
        {
            return AlgorithmIdentifier.getInstance(params);
        }
        catch (IllegalArgumentException e)
        {
            throw new CMSException("unable to read RFC 9709 content-encryption algorithm: " + e.getMessage(), e);
        }
    }

    private static final Map asymmetricWrapperAlgNames = new HashMap();

    private static Map<ASN1ObjectIdentifier,String> wrapAlgNames = new HashMap();

    static
    {
       wrapAlgNames.put(CMSAlgorithm.AES128_WRAP, "AESWRAP");
       wrapAlgNames.put(CMSAlgorithm.AES192_WRAP, "AESWRAP");
       wrapAlgNames.put(CMSAlgorithm.AES256_WRAP, "AESWRAP");
       wrapAlgNames.put(CMSAlgorithm.AES128_WRAP_PAD, "AES-KWP");
       wrapAlgNames.put(CMSAlgorithm.AES192_WRAP_PAD, "AES-KWP");
       wrapAlgNames.put(CMSAlgorithm.AES256_WRAP_PAD, "AES-KWP");
    }

    static
    {
        asymmetricWrapperAlgNames.put(PKCSObjectIdentifiers.rsaEncryption, "RSA/ECB/PKCS1Padding");
        asymmetricWrapperAlgNames.put(OIWObjectIdentifiers.elGamalAlgorithm, "Elgamal/ECB/PKCS1Padding");
        asymmetricWrapperAlgNames.put(PKCSObjectIdentifiers.id_RSAES_OAEP, "RSA/ECB/OAEPPadding");
        asymmetricWrapperAlgNames.put(CryptoProObjectIdentifiers.gostR3410_2001, "ECGOST3410");
        asymmetricWrapperAlgNames.put(ISOIECObjectIdentifiers.id_kem_rsa, "RSA-KTS-KEM-KWS");
    }

    static String getWrapAlgorithmName(ASN1ObjectIdentifier oid)
    {
        return (String)wrapAlgNames.get(oid);
    }

    static PrivateKey cleanPrivateKey(PrivateKey key)
    {
        if (key instanceof AnnotatedPrivateKey)
        {
            return cleanPrivateKey(((AnnotatedPrivateKey)key).getKey());
        }
        else
        {
            return key;
        }
    }

    static IssuerAndSerialNumber getIssuerAndSerialNumber(X509Certificate cert)
        throws CertificateEncodingException
    {
        Certificate certStruct = Certificate.getInstance(cert.getEncoded());

        return new IssuerAndSerialNumber(certStruct.getIssuer(), cert.getSerialNumber());
    }

    static byte[] getSubjectKeyId(X509Certificate cert)
    {
        byte[] ext = cert.getExtensionValue(Extension.subjectKeyIdentifier.getId());

        if (ext != null)
        {
            return ASN1OctetString.getInstance(ASN1OctetString.getInstance(ext).getOctets()).getOctets();
        }
        else
        {
            return null;
        }
    }

    static EnvelopedDataHelper createDefaultHelper()
    {
        return new EnvelopedDataHelper(new DefaultJcaJceExtHelper());
    }

    static EnvelopedDataHelper createProviderHelper(Provider provider)
    {
        return new EnvelopedDataHelper(new ProviderJcaJceExtHelper(provider));
    }

    static EnvelopedDataHelper createNamedHelper(String providerName)
    {
        return new EnvelopedDataHelper(new NamedJcaJceExtHelper(providerName));
    }

    static EnvelopedDataHelper createContentHelper(Provider provider)
    {
        if (provider != null)
        {
            return createProviderHelper(provider);
        }
        else
        {
            return createDefaultHelper();
        }
    }

    static EnvelopedDataHelper createContentHelper(String providerName)
    {
        if (providerName != null)
        {
            return createNamedHelper(providerName);
        }
        else
        {
            return createDefaultHelper();
        }
    }

    static ASN1Encodable extractParameters(AlgorithmParameters params)
        throws CMSException
    {
        try
        {
            return AlgorithmParametersUtils.extractParameters(params);
        }
        catch (IOException e)
        {
            throw new CMSException("cannot extract parameters: " + e.getMessage(), e);
        }
    }

    static void loadParameters(AlgorithmParameters params, ASN1Encodable sParams)
        throws CMSException
    {
        try
        {
            AlgorithmParametersUtils.loadParameters(params, sParams);
        }
        catch (IOException e)
        {
            throw new CMSException("error encoding algorithm parameters.", e);
        }
    }

    /**
     * Return the AEAD authentication tag (ICV) length in octets used to size the MAC capture for an
     * auth-enveloped content encryption algorithm.
     * <p>
     * ChaCha20Poly1305 always uses a 16 octet tag. AES-GCM and AES-CCM both carry their parameters as a
     * SEQUENCE { nonce, ICVlen DEFAULT 12 }, so the tag length is read directly from the sequence rather
     * than via GCMParameters.getInstance - the latter would reject anything below the RFC 5084 GCM minimum
     * of 12 octets, whereas CCM permits valid shorter tags (e.g. 64-bit / 8 octets).
     *
     * @param algId the (unwrapped) content encryption algorithm identifier.
     * @return the tag length in octets.
     */
    static int getAEADMacLength(AlgorithmIdentifier algId)
    {
        if (CMSAlgorithm.ChaCha20Poly1305.equals(algId.getAlgorithm()))
        {
            return 16;
        }

        ASN1Sequence seq = ASN1Sequence.getInstance(algId.getParameters());
        if (seq.size() > 2)
        {
            throw new IllegalArgumentException("malformed AEAD parameters: unexpected sequence size " + seq.size());
        }
        int icvLen = (seq.size() > 1) ? ASN1Integer.getInstance(seq.getObjectAt(1)).intValueExact() : 12;
        if (icvLen < 4)
        {
            throw new IllegalArgumentException("malformed AEAD parameters: icvLen < 4");
        }

        return icvLen;
    }

    static Key getJceKey(GenericKey key)
    {
        if (key.getRepresentation() instanceof Key)
        {
            return (Key)key.getRepresentation();
        }

        if (key.getRepresentation() instanceof byte[])
        {
            return new SecretKeySpec((byte[])key.getRepresentation(), "ENC");
        }

        throw new IllegalArgumentException("unknown generic key type");
    }

    static Cipher createAsymmetricWrapper(JcaJceHelper helper, ASN1ObjectIdentifier algorithm, Map extraAlgNames)
        throws OperatorCreationException
    {
        try
        {
            String cipherName = null;

            if (!extraAlgNames.isEmpty())
            {
                cipherName = (String)extraAlgNames.get(algorithm);
            }

            if (cipherName == null)
            {
                cipherName = (String)asymmetricWrapperAlgNames.get(algorithm);
            }

            if (cipherName != null)
            {
                try
                {
                    // this is reversed as the Sun policy files now allow unlimited strength RSA
                    return helper.createCipher(cipherName);
                }
                catch (NoSuchAlgorithmException e)
                {
                    // try alternate for RSA
                    if (cipherName.equals("RSA/ECB/PKCS1Padding"))
                    {
                        try
                        {
                            return helper.createCipher("RSA/NONE/PKCS1Padding");
                        }
                        catch (NoSuchAlgorithmException ex)
                        {
                            // Ignore
                        }
                    }
                    // Ignore
                }
            }

            return helper.createCipher(algorithm.getId());
        }
        catch (GeneralSecurityException e)
        {
            throw new OperatorCreationException("cannot create cipher: " + e.getMessage(), e);
        }
    }

    public static int getKekSize(ASN1ObjectIdentifier symWrapAlg)
    {
        // TODO: add table
        if (symWrapAlg.equals(CMSAlgorithm.AES256_WRAP) || symWrapAlg.equals(CMSAlgorithm.AES256_WRAP_PAD))
        {
            return 32;
        }
        else if (symWrapAlg.equals(CMSAlgorithm.AES128_WRAP) || symWrapAlg.equals(CMSAlgorithm.AES128_WRAP_PAD))
        {
            return  16;
        }
        else if (symWrapAlg.equals(CMSAlgorithm.AES192_WRAP) || symWrapAlg.equals(CMSAlgorithm.AES192_WRAP_PAD))
        {
            return  24;
        }
        else
        {
            throw new IllegalArgumentException("unknown wrap algorithm: " + symWrapAlg);
        }
    }
}