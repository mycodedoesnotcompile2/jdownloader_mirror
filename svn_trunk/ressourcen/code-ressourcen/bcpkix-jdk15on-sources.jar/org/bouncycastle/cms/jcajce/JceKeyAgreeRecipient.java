package org.bouncycastle.cms.jcajce;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.PublicKey;
import java.security.spec.AlgorithmParameterSpec;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.HashSet;
import java.util.Set;

import javax.crypto.Cipher;
import javax.crypto.KeyAgreement;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;

import org.bouncycastle.asn1.ASN1Encoding;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.DERNull;
import org.bouncycastle.asn1.cms.ecc.ECCCMSSharedInfo;
import org.bouncycastle.asn1.cms.ecc.MQVuserKeyingMaterial;
import org.bouncycastle.asn1.cryptopro.CryptoProObjectIdentifiers;
import org.bouncycastle.asn1.cryptopro.Gost2814789EncryptedKey;
import org.bouncycastle.asn1.cryptopro.Gost2814789KeyWrapParameters;
import org.bouncycastle.asn1.pkcs.PrivateKeyInfo;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.asn1.x9.X9ObjectIdentifiers;
import org.bouncycastle.cms.AbstractKeyAgreeRecipient;
import org.bouncycastle.cms.CMSException;
import org.bouncycastle.jcajce.spec.GOST28147WrapParameterSpec;
import org.bouncycastle.jcajce.spec.MQVParameterSpec;
import org.bouncycastle.jcajce.spec.UserKeyingMaterialSpec;
import org.bouncycastle.operator.DefaultSecretKeySizeProvider;
import org.bouncycastle.operator.SecretKeySizeProvider;
import org.bouncycastle.util.Arrays;
import org.bouncycastle.util.Properties;
import org.bouncycastle.util.Exceptions;
import org.bouncycastle.util.Pack;

public abstract class JceKeyAgreeRecipient
    extends AbstractKeyAgreeRecipient
{
    private static final Set possibleOldMessages = new HashSet();

    static
    {
        possibleOldMessages.add(X9ObjectIdentifiers.dhSinglePass_stdDH_sha1kdf_scheme);
        possibleOldMessages.add(X9ObjectIdentifiers.mqvSinglePass_sha1kdf_scheme);
    }

    private PrivateKey recipientKey;
    protected EnvelopedDataHelper helper = CMSUtils.createDefaultHelper();
    protected EnvelopedDataHelper contentHelper = helper;
    protected EnvelopedDataHelper unwrappingHelper = helper;
    private SecretKeySizeProvider keySizeProvider = new DefaultSecretKeySizeProvider();
    private AlgorithmIdentifier privKeyAlgID = null;

    public JceKeyAgreeRecipient(PrivateKey recipientKey)
    {
        this.recipientKey = CMSUtils.cleanPrivateKey(recipientKey);
    }

    /**
     * Set the provider to use for key recovery and content processing.
     *
     * @param provider provider to use.
     * @return this recipient.
     */
    public JceKeyAgreeRecipient setProvider(Provider provider)
    {
        this.helper = CMSUtils.createProviderHelper(provider);
        this.contentHelper = helper;
        this.unwrappingHelper = helper;

        return this;
    }

    /**
     * Set the provider to use for key recovery and content processing.
     *
     * @param providerName the name of the provider to use.
     * @return this recipient.
     */
    public JceKeyAgreeRecipient setProvider(String providerName)
    {
        this.helper = CMSUtils.createNamedHelper(providerName);
        this.contentHelper = helper;
        this.unwrappingHelper = helper;

        return this;
    }

    /**
     * Set the provider to use for unwrapping the content session key.
     *
     * @param provider provider to use.
     * @return this recipient.
     */
    public JceKeyAgreeRecipient setUnwrappingProvider(Provider provider)
    {
        this.unwrappingHelper = CMSUtils.createProviderHelper(provider);

        return this;
    }

    /**
     * Set the provider to use for unwrapping the content session key.
     *
     * @param providerName the name of the provider to use.
     * @return this recipient.
     */
    public JceKeyAgreeRecipient setUnwrappingProvider(String providerName)
    {
        this.unwrappingHelper = CMSUtils.createNamedHelper(providerName);

        return this;
    }

    /**
     * Set the provider to use for content processing.  If providerName is null a "no provider" search will be
     *  used to satisfy getInstance calls.
     *
     * @param provider the provider to use.
     * @return this recipient.
     */
    public JceKeyAgreeRecipient setContentProvider(Provider provider)
    {
        this.contentHelper = CMSUtils.createContentHelper(provider);

        return this;
    }

    /**
     * Set the provider to use for content processing. If providerName is null a "no provider" search will be
     * used to satisfy getInstance calls.
     *
     * @param providerName the name of the provider to use.
     * @return this recipient.
     */
    public JceKeyAgreeRecipient setContentProvider(String providerName)
    {
        this.contentHelper = CMSUtils.createContentHelper(providerName);

        return this;
    }

    /**
     * Set the algorithm identifier for the private key. You'll want to use this if you are
     * dealing with a HSM and it is not possible to get the encoding of the private key.
     *
     * @param privKeyAlgID the algorithm identifier for the private key.
     * @return this recipient.
     */
    public JceKeyAgreeRecipient setPrivateKeyAlgorithmIdentifier(AlgorithmIdentifier privKeyAlgID)
    {
        this.privKeyAlgID = privKeyAlgID;

        return this;
    }

    /**
     * Set the content-encryption algorithms this recipient is willing to unwrap a key for. When set, an
     * attempt to recover content protected under any other algorithm is rejected, mitigating an attacker
     * substituting a weaker content-encryption algorithm into the recipient info.
     *
     * @param allowedContentAlgorithms the set of permitted content-encryption algorithm OIDs.
     * @return this recipient.
     */
    public JceKeyAgreeRecipient setAllowedContentAlgorithms(Set<ASN1ObjectIdentifier> allowedContentAlgorithms)
    {
        setAllowedContentAlgorithmSet(allowedContentAlgorithms);

        return this;
    }

    /**
     * Set the minimum AEAD authentication tag size (in bits) this recipient will accept. When set, an
     * attempt to recover AuthEnvelopedData whose content algorithm carries a shorter tag is rejected,
     * mitigating an attacker downgrading the tag to a weaker length.
     *
     * @param tagSizeInBits the minimum acceptable AEAD tag size, in bits.
     * @return this recipient.
     */
    public JceKeyAgreeRecipient setMinimumTagSize(int tagSizeInBits)
    {
        setMinimumTagSizeInBits(tagSizeInBits);

        return this;
    }

    private SecretKey calculateAgreedWrapKey(AlgorithmIdentifier keyEncAlg, AlgorithmIdentifier wrapAlg,
                                             PublicKey senderPublicKey, ASN1OctetString userKeyingMaterial, PrivateKey receiverPrivateKey, KeyMaterialGenerator kmGen)
        throws CMSException, GeneralSecurityException, IOException
    {
        ASN1ObjectIdentifier agreeAlgOID = keyEncAlg.getAlgorithm();

        receiverPrivateKey = CMSUtils.cleanPrivateKey(receiverPrivateKey);

        AlgorithmParameterSpec initParams = null;

        if (isMQV(agreeAlgOID))
        {
            // RFC 5753 sec. 3.2.1: for 1-Pass ECMQV the ukm MUST be present
            if (userKeyingMaterial == null)
            {
                throw new CMSException("User keying material must be present for MQV.");
            }

            MQVuserKeyingMaterial ukm = MQVuserKeyingMaterial.getInstance(userKeyingMaterial.getOctets());

            SubjectPublicKeyInfo pubInfo = new SubjectPublicKeyInfo(
                getPrivateKeyAlgorithmIdentifier(),
                ukm.getEphemeralPublicKey().getPublicKeyData());

            X509EncodedKeySpec pubSpec = new X509EncodedKeySpec(pubInfo.getEncoded());
            KeyFactory fact = helper.createKeyFactory(agreeAlgOID);
            PublicKey ephemeralKey = fact.generatePublic(pubSpec);

            // RFC 5753 sec. 3.2.3 / 7.2: the KDF SharedInfo is DER(ECC-CMS-SharedInfo) with the addedukm as
            // its entityUInfo, exactly as for ECDH; the generator passed in selects which form is tried.
            byte[] addedukm = (ukm.getAddedukm() != null) ? ukm.getAddedukm().getOctets() : null;
            byte[] ukmKeyingMaterial = kmGen.generateKDFMaterial(wrapAlg, keySizeProvider.getKeySize(wrapAlg), addedukm);

            initParams = new MQVParameterSpec(receiverPrivateKey, ephemeralKey, ukmKeyingMaterial);
        }
        else
        {
            if (isEC(agreeAlgOID))
            {
                byte[] ukmKeyingMaterial;
                if (userKeyingMaterial != null)
                {
                    ukmKeyingMaterial = kmGen.generateKDFMaterial(wrapAlg, keySizeProvider.getKeySize(wrapAlg), userKeyingMaterial.getOctets());
                }
                else
                {
                    ukmKeyingMaterial = kmGen.generateKDFMaterial(wrapAlg, keySizeProvider.getKeySize(wrapAlg), null);
                }
                // RFC 8418 sec. 2.2: for the HKDF schemes a ukm is both the entityUInfo of the
                // ECC-CMS-SharedInfo and the HKDF salt
                if (userKeyingMaterial != null && isHKDF(agreeAlgOID))
                {
                    initParams = new UserKeyingMaterialSpec(ukmKeyingMaterial, userKeyingMaterial.getOctets());
                }
                else
                {
                    initParams = new UserKeyingMaterialSpec(ukmKeyingMaterial);
                }
            }
            else if (isRFC2631(agreeAlgOID))
            {
                if (userKeyingMaterial != null)
                {
                    initParams = new UserKeyingMaterialSpec(userKeyingMaterial.getOctets());
                }
            }
            else if (isGOST(agreeAlgOID))
            {
                if (userKeyingMaterial != null)
                {
                    initParams = new UserKeyingMaterialSpec(userKeyingMaterial.getOctets());
                }
            }
            else
            {
                throw new CMSException("Unknown key agreement algorithm: " + agreeAlgOID);
            }
        }

        KeyAgreement agreement = helper.createKeyAgreement(agreeAlgOID);

        agreement.init(receiverPrivateKey, initParams);
        agreement.doPhase(senderPublicKey, true);

        return agreement.generateSecret(wrapAlg.getAlgorithm().getId());
    }

    protected Key unwrapSessionKey(ASN1ObjectIdentifier wrapAlg, SecretKey agreedKey, ASN1ObjectIdentifier contentEncryptionAlgorithm, byte[] encryptedContentEncryptionKey)
        throws CMSException, InvalidKeyException, NoSuchAlgorithmException
    {
        Cipher keyCipher = unwrappingHelper.createCipher(wrapAlg);
        keyCipher.init(Cipher.UNWRAP_MODE, agreedKey);
        return keyCipher.unwrap(encryptedContentEncryptionKey, helper.getBaseCipherName(contentEncryptionAlgorithm), Cipher.SECRET_KEY);
    }

    protected Key extractSecretKey(AlgorithmIdentifier keyEncryptionAlgorithm, AlgorithmIdentifier contentEncryptionAlgorithm, SubjectPublicKeyInfo senderKey, ASN1OctetString userKeyingMaterial, byte[] encryptedContentEncryptionKey)
        throws CMSException
    {
        checkContentAlgorithm(contentEncryptionAlgorithm);

        try
        {
            AlgorithmIdentifier wrapAlgID = AlgorithmIdentifier.getInstance(keyEncryptionAlgorithm.getParameters());
            ASN1ObjectIdentifier wrapAlgOID = wrapAlgID.getAlgorithm();

            X509EncodedKeySpec pubSpec = new X509EncodedKeySpec(senderKey.getEncoded());
            KeyFactory fact = helper.createKeyFactory(senderKey.getAlgorithm().getAlgorithm());
            PublicKey senderPublicKey = fact.generatePublic(pubSpec);

            try
            {
                SecretKey agreedWrapKey = calculateAgreedWrapKey(keyEncryptionAlgorithm, wrapAlgID, senderPublicKey,
                    userKeyingMaterial, recipientKey, ecc_cms_Generator);

                if (CryptoProObjectIdentifiers.id_Gost28147_89_None_KeyWrap.equals(wrapAlgOID) ||
                    CryptoProObjectIdentifiers.id_Gost28147_89_CryptoPro_KeyWrap.equals(wrapAlgOID))
                {
                    Gost2814789EncryptedKey encKey = Gost2814789EncryptedKey.getInstance(encryptedContentEncryptionKey);
                    Gost2814789KeyWrapParameters wrapParams = Gost2814789KeyWrapParameters.getInstance(
                        wrapAlgID.getParameters());

                    Cipher keyCipher = helper.createCipher(wrapAlgOID);

                    keyCipher.init(Cipher.UNWRAP_MODE, agreedWrapKey,
                        new GOST28147WrapParameterSpec(wrapParams.getEncryptionParamSet(), userKeyingMaterial.getOctets()));

                    byte[] wrappedKey = Arrays.concatenate(encKey.getEncryptedKey(), encKey.getMacKey());
                    return keyCipher.unwrap(wrappedKey, helper.getBaseCipherName(contentEncryptionAlgorithm.getAlgorithm()),
                        Cipher.SECRET_KEY);
                }

                return unwrapSessionKey(wrapAlgOID, agreedWrapKey, contentEncryptionAlgorithm.getAlgorithm(),
                    encryptedContentEncryptionKey);
            }
            catch (InvalidKeyException e)
            {
                // might be a pre-RFC 5753 message
                if (possibleOldMessages.contains(keyEncryptionAlgorithm.getAlgorithm()))
                {
                    try
                    {
                        SecretKey agreedWrapKey = calculateAgreedWrapKey(keyEncryptionAlgorithm, wrapAlgID,
                            senderPublicKey, userKeyingMaterial, recipientKey, old_ecc_cms_Generator);

                        return unwrapSessionKey(wrapAlgOID, agreedWrapKey, contentEncryptionAlgorithm.getAlgorithm(),
                            encryptedContentEncryptionKey);
                    }
                    catch (InvalidKeyException ex)
                    {
                        // fall through to the raw ukm form, reporting the original failure if that fails too
                    }
                }
                // one last try - the raw ukm as the KDF SharedInfo: people do actually do this it turns out, and
                // for ECMQV it is the form BC itself produced from 1.53 to 1.86.
                if (userKeyingMaterial != null && Properties.isOverrideSet(Properties.CMS_ALLOW_LEGACY_KEYAGREE_KDF, true))
                {
                    try
                    {
                        SecretKey agreedWrapKey = calculateAgreedWrapKey(keyEncryptionAlgorithm, wrapAlgID,
                            senderPublicKey, userKeyingMaterial, recipientKey, simple_ecc_cmsGenerator);

                        return unwrapSessionKey(wrapAlgOID, agreedWrapKey, contentEncryptionAlgorithm.getAlgorithm(),
                            encryptedContentEncryptionKey);
                    }
                    catch (InvalidKeyException ex)
                    {
                        throw e; // we'll throw the original exception
                    }
                }
                throw e;
            }
        }
        catch (NoSuchAlgorithmException e)
        {
            throw new CMSException("can't find algorithm.", e);
        }
        catch (InvalidKeyException e)
        {
            throw new CMSException("key invalid in message.", e);
        }
        catch (InvalidKeySpecException e)
        {
            throw new CMSException("originator key spec invalid.", e);
        }
        catch (NoSuchPaddingException e)
        {
            throw new CMSException("required padding not supported.", e);
        }
        catch (CMSException e)
        {
            throw e;
        }
        catch (Exception e)
        {
            throw new CMSException("originator key invalid.", e);
        }
    }

    public AlgorithmIdentifier getPrivateKeyAlgorithmIdentifier()
    {
        if (privKeyAlgID == null)
        {
            privKeyAlgID = PrivateKeyInfo.getInstance(recipientKey.getEncoded()).getPrivateKeyAlgorithm();
        }

        return privKeyAlgID;
    }

    private static KeyMaterialGenerator old_ecc_cms_Generator = new KeyMaterialGenerator()
    {
        public byte[] generateKDFMaterial(AlgorithmIdentifier keyAlgorithm, int keySize, byte[] userKeyMaterialParameters)
        {
            ECCCMSSharedInfo eccInfo;

            // this isn't correct with AES and RFC 5753, but we have messages predating it...
            eccInfo = new ECCCMSSharedInfo(new AlgorithmIdentifier(keyAlgorithm.getAlgorithm(), DERNull.INSTANCE), userKeyMaterialParameters, Pack.intToBigEndian(keySize));

            try
            {
                return eccInfo.getEncoded(ASN1Encoding.DER);
            }
            catch (IOException e)
            {
                throw Exceptions.illegalStateException("Unable to create KDF material", e);
            }
        }
    };

    private static KeyMaterialGenerator simple_ecc_cmsGenerator = new KeyMaterialGenerator()
    {
        public byte[] generateKDFMaterial(AlgorithmIdentifier keyAlgorithm, int keySize, byte[] userKeyMaterialParameters)
        {
            return userKeyMaterialParameters;
        }
    };

    private static KeyMaterialGenerator ecc_cms_Generator = new RFC5753KeyMaterialGenerator();
}
