package org.bouncycastle.cms;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.bouncycastle.asn1.ASN1Encoding;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1OctetStringParser;
import org.bouncycastle.asn1.ASN1ParsingException;
import org.bouncycastle.asn1.ASN1SequenceParser;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.ASN1SetParser;
import org.bouncycastle.asn1.BERTags;
import org.bouncycastle.asn1.cms.AttributeTable;
import org.bouncycastle.asn1.cms.AuthEnvelopedDataParser;
import org.bouncycastle.asn1.cms.CMSAttributes;
import org.bouncycastle.asn1.cms.EncryptedContentInfoParser;
import org.bouncycastle.asn1.cms.OriginatorInfo;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.util.Arrays;

/**
 * Parser for authenticated enveloped CMS data structures.
 * <p>
 * <b>Stream handling note:</b>
 * <ul>
 *   <li>The constructor reads only enough of the supplied InputStream to expose the
 *       CMS structure metadata (originator info, recipient infos, content-encryption
 *       algorithm). The encrypted content and trailing MAC are drained lazily by the
 *       caller via {@link RecipientInformation#getContentStream} /
 *       {@link RecipientInformation#getContent}; the MAC is verified when the content
 *       stream reaches EOF.</li>
 *   <li>The supplied InputStream is <b>not closed automatically</b>. Call
 *       {@link #close()} on this parser (inherited from
 *       {@link CMSContentInfoParser}) to close the underlying InputStream, or close
 *       it yourself.</li>
 *   <li>This class does not introduce buffering &mdash; if you are processing large
 *       inputs, wrap the InputStream in a {@link java.io.BufferedInputStream}.</li>
 * </ul>
 */
public class CMSAuthEnvelopedDataParser
    extends CMSContentInfoParser
{
    private final RecipientInformationStore recipientInfoStore;
    private final AuthEnvelopedDataParser authEvnData;
    private final LocalMacProvider localMacProvider;
    private final AlgorithmIdentifier encAlg;
    private AttributeTable authAttrs;
    private ASN1Set authAttrSet;
    private AttributeTable unauthAttrs;

    private boolean authAttrNotRead;
    private boolean unauthAttrNotRead;
    private OriginatorInformation originatorInfo;

    /**
     * Create a parser from a byte array.
     *
     * @param envelopedData the CMS auth enveloped data bytes
     */
    public CMSAuthEnvelopedDataParser(
        byte[] envelopedData)
        throws CMSException, IOException
    {
        this(new ByteArrayInputStream(envelopedData));
    }

    /**
     * Create a parser from an input stream. See the class-level javadoc for the
     * stream handling protocol &mdash; the content is drained lazily via
     * {@link RecipientInformation#getContentStream}, and the supplied InputStream
     * is not closed automatically.
     *
     * @param envelopedData the CMS auth enveloped data stream
     */
    public CMSAuthEnvelopedDataParser(
        InputStream envelopedData)
        throws CMSException, IOException
    {
        super(envelopedData);

        try
        {
            authAttrNotRead = true;
            unauthAttrNotRead = true;
            ASN1SequenceParser content = (ASN1SequenceParser)_contentInfo.getContent(BERTags.SEQUENCE);
            if (content == null)
            {
                throw new CMSException("Missing content.");
            }

            authEvnData = new AuthEnvelopedDataParser(content);

            OriginatorInfo info = authEvnData.getOriginatorInfo();

            if (info != null)
            {
                this.originatorInfo = new OriginatorInformation(info);
            }
            //
            // read the recipients
            //
            ASN1Set recipientInfos = ASN1Set.getInstance(authEvnData.getRecipientInfos().toASN1Primitive());

            final EncryptedContentInfoParser encInfo = authEvnData.getAuthEncryptedContentInfo();

            encAlg = encInfo.getContentEncryptionAlgorithm();
            localMacProvider = new LocalMacProvider(authEvnData, this);

            ASN1OctetStringParser encContent = (ASN1OctetStringParser)encInfo.getEncryptedContent(BERTags.OCTET_STRING);
            if (encContent == null)
            {
                throw new CMSException("Missing content.");
            }

            final CMSReadable readable = new CMSProcessableInputStream(new InputStreamWithMAC(
                encContent.getOctetStream(), localMacProvider));

            CMSSecureReadableWithAAD secureReadable = new CMSSecureReadableWithAAD()
            {
                private OutputStream aadStream;

                 
                public ASN1ObjectIdentifier getContentType()
                {
                    return encInfo.getContentType();
                }

                 
                public InputStream getInputStream()
                    throws IOException, CMSException
                {
                    return readable.getInputStream();
                }

                 
                public ASN1Set getAuthAttrSet()
                {
                    return authAttrSet;
                }

                 
                public void setAuthAttrSet(ASN1Set set)
                {

                }

                 
                public boolean hasAdditionalData()
                {
                    return true;
                }

                 
                public void setAADStream(OutputStream stream)
                {
                    aadStream = stream;
                }

                 
                public OutputStream getAADStream()
                {
                    return aadStream;
                }

                 
                public byte[] getMAC()
                {
                    return Arrays.clone(localMacProvider.getMAC());
                }
            };

            localMacProvider.setSecureReadable(secureReadable);
            //
            // build the RecipientInformationStore
            //
            this.recipientInfoStore = CMSEnvelopedHelper.buildRecipientInformationStore(recipientInfos, this.encAlg, secureReadable);
        }
        catch (ClassCastException e)
        {
            throw new CMSException("Malformed content.", e);
        }
        catch (IllegalArgumentException e)
        {
            throw new CMSException("Malformed content.", e);
        }
        catch (ASN1ParsingException e)
        {
            throw new CMSException("Malformed content.", e);
        }
    }

    /**
     * Return the originator information associated with this message if present.
     *
     * @return OriginatorInformation, null if not present.
     */
    public OriginatorInformation getOriginatorInfo()
    {
        return originatorInfo;
    }

    /**
     * Return the MAC algorithm details for the MAC associated with the data in this object.
     *
     * @return AlgorithmIdentifier representing the MAC algorithm.
     */
    public AlgorithmIdentifier getEncryptionAlgOID()
    {
        return encAlg;
    }

    /**
     * return the object identifier for the mac algorithm.
     */
    public String getEncAlgOID()
    {
        return encAlg.getAlgorithm().toString();
    }

    /**
     * return the ASN.1 encoded encryption algorithm parameters, or null if
     * there aren't any.
     */
    public byte[] getEncAlgParams()
    {
        try
        {
            return CMSUtils.encodeObj(encAlg.getParameters());
        }
        catch (Exception e)
        {
            throw new RuntimeException("exception getting encryption parameters " + e);
        }
    }

    /**
     * return a store of the intended recipients for this message
     */
    public RecipientInformationStore getRecipientInfos()
    {
        return recipientInfoStore;
    }

    public byte[] getMac()
        throws IOException
    {
        return Arrays.clone(localMacProvider.getMAC());
    }

    private ASN1Set getAuthAttrSet()
        throws IOException
    {
        if (authAttrs == null && authAttrNotRead)
        {
            ASN1SetParser set = authEvnData.getAuthAttrs();

            if (set != null)
            {
                authAttrSet = ASN1Set.getInstance(set.getLoadedObject());
            }

            authAttrNotRead = false;
        }

        return authAttrSet;
    }

    /**
     * return a table of the authenticated attributes indexed by
     * the OID of the attribute.
     */
    public AttributeTable getAuthAttrs()
        throws IOException
    {
        if (authAttrs == null && authAttrNotRead)
        {
            ASN1Set set = getAuthAttrSet();

            if (set != null)
            {
                authAttrs = CMSUtils.getAttributeTable(set);
            }
        }

        return authAttrs;
    }

    /**
     * return a table of the unauthenticated attributes indexed by
     * the OID of the attribute.
     */
    public AttributeTable getUnauthAttrs()
        throws IOException
    {
        if (unauthAttrs == null && unauthAttrNotRead)
        {
            unauthAttrNotRead = false;
            unauthAttrs = CMSUtils.getAttributesTable(authEvnData.getUnauthAttrs());
        }

        return unauthAttrs;
    }

    /**
     * This will only be valid after the content has been read.
     *
     * @return the contents of the messageDigest attribute, if available. Null if not present.
     */
    public byte[] getContentDigest()
    {
        if (authAttrs != null)
        {
            return ASN1OctetString.getInstance(authAttrs.get(CMSAttributes.messageDigest).getAttrValues().getObjectAt(0)).getOctets();
        }

        return null;
    }

    static class LocalMacProvider
        implements MACProvider
    {
        private byte[] mac;
        private final AuthEnvelopedDataParser authEnvData;
        private final CMSAuthEnvelopedDataParser parser;
        private CMSSecureReadableWithAAD readable;

        LocalMacProvider(AuthEnvelopedDataParser authEnvData, CMSAuthEnvelopedDataParser parser)
        {
            this.authEnvData = authEnvData;
            this.parser = parser;
        }

        public void init()
            throws IOException
        {
            parser.authAttrs = parser.getAuthAttrs();
            if (parser.authAttrs != null)
            {
                readable.setAuthAttrSet(parser.authAttrSet);
                readable.getAADStream().write(parser.authAttrs.toASN1Structure().getEncoded(ASN1Encoding.DER));
            }
            mac = authEnvData.getMac().getOctets();
        }

        void setSecureReadable(CMSSecureReadableWithAAD secureReadable)
        {
            readable = secureReadable;
        }

        public byte[] getMAC()
        {
            return mac;
        }
    }
}

