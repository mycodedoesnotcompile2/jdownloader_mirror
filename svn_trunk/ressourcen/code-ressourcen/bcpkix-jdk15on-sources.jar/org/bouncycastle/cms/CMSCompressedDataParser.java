package org.bouncycastle.cms;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.bouncycastle.asn1.ASN1OctetStringParser;
import org.bouncycastle.asn1.ASN1SequenceParser;
import org.bouncycastle.asn1.BERTags;
import org.bouncycastle.asn1.cms.CompressedDataParser;
import org.bouncycastle.asn1.cms.ContentInfoParser;
import org.bouncycastle.operator.InputExpander;
import org.bouncycastle.operator.InputExpanderProvider;

/**
 * Class for reading a CMS Compressed Data stream.
 * <pre>
 *     CMSCompressedDataParser cp = new CMSCompressedDataParser(inputStream);
 *      
 *     process(cp.getContent(new ZlibExpanderProvider()).getContentStream());
 * </pre>
 *  Note: this class does not introduce buffering - if you are processing large files you should create
 *  the parser with:
 *  <pre>
 *      CMSCompressedDataParser     ep = new CMSCompressedDataParser(new BufferedInputStream(inputStream, bufSize));
 *  </pre>
 *  where bufSize is a suitably large buffer size.
 * <p>
 * <b>Stream handling note:</b>
 * <ul>
 *   <li>The constructor reads only the outer CMS ContentInfo header from the
 *       supplied InputStream. The compressed content is drained lazily by the
 *       caller via {@link #getContent(InputExpanderProvider)} and reading from the
 *       returned {@link CMSTypedStream}.</li>
 *   <li>The supplied InputStream is <b>not closed automatically</b>. Call
 *       {@link #close()} on this parser (inherited from
 *       {@link CMSContentInfoParser}) to close the underlying InputStream, or close
 *       it yourself.</li>
 * </ul>
 */
public class CMSCompressedDataParser
    extends CMSContentInfoParser
{
    public CMSCompressedDataParser(
        byte[]    compressedData) 
        throws CMSException
    {
        this(new ByteArrayInputStream(compressedData));
    }

    public CMSCompressedDataParser(
        InputStream    compressedData) 
        throws CMSException
    {
        super(compressedData);
    }

    /**
     * Return a typed stream which will allow the reading of the compressed content in
     * expanded form.
     *
     * @param expanderProvider a provider of expander algorithm implementations.
     * @return a type stream which will yield the un-compressed content.
     * @throws CMSException if there is an exception parsing the CompressedData object.
     */
    public CMSTypedStream  getContent(InputExpanderProvider expanderProvider)
        throws CMSException
    {
        try
        {
            ASN1SequenceParser seq = (ASN1SequenceParser)_contentInfo.getContent(BERTags.SEQUENCE);
            if (seq == null)
            {
                throw new CMSException("Missing content.");
            }

            CompressedDataParser  comData = new CompressedDataParser(seq);
            ContentInfoParser     content = comData.getEncapContentInfo();
            InputExpander expander = expanderProvider.get(comData.getCompressionAlgorithmIdentifier());

            ASN1OctetStringParser bytes = (ASN1OctetStringParser)content.getContent(BERTags.OCTET_STRING);
            if (bytes == null)
            {
                throw new CMSException("Missing content.");
            }

            return new CMSTypedStream(content.getContentType(), expander.getInputStream(bytes.getOctetStream()));
        }
        catch (IOException e)
        {
            throw new CMSException("IOException reading compressed content.", e);
        }
        catch (ClassCastException e)
        {
            throw new CMSException("Malformed content.", e);
        }
        catch (IllegalArgumentException e)
        {
            throw new CMSException("Malformed content.", e);
        }
    }
}
