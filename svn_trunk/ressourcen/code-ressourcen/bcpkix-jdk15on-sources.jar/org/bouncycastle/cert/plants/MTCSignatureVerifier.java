package org.bouncycastle.cert.plants;

/**
 * Operator interface for verifying a single cosigner signature over a
 * pre-encoded CosignedSubtree, per Section 5.3.1 of
 * draft-ietf-plants-merkle-tree-certs.
 *
 * <p>An implementation is bound to a specific public key and algorithm at
 * construction; callers feed it the CosignedSubtree bytes (built via
 * {@link MTCCosignedSubtree#encode}) and the candidate signature, and the
 * implementation returns whether the signature is valid.</p>
 *
 * <p>JCA-free and lightweight-crypto-free. Concrete bindings:
 * {@code org.bouncycastle.cert.plants.bc.BcMTCSignatureVerifier} (lightweight)
 * and
 * {@code org.bouncycastle.cert.plants.jcajce.JcaMTCSignatureVerifier} (JCA).</p>
 */
public interface MTCSignatureVerifier
{
    /**
     * @return the MTC signature algorithm this verifier is bound to — one of
     *         the {@link MTCSignatureAlgorithm} constants. Lets callers check
     *         a registered verifier against the algorithm a CA publishes for
     *         its cosigner (Section 5.5 {@code sigAlg}).
     */
    String getAlgorithm();

    /**
     * @param cosignedMessage the encoded CosignedSubtree bytes
     * @param signature       the candidate signature
     * @return true if the signature is valid for the bound public key and algorithm
     */
    boolean verify(byte[] cosignedMessage, byte[] signature);
}
