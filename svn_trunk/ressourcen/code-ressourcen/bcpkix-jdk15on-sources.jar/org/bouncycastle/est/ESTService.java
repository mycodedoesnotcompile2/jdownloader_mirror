package org.bouncycastle.est;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;
import java.util.regex.Pattern;

import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.cms.ContentInfo;
import org.bouncycastle.asn1.est.CsrAttrs;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.asn1.pkcs.PrivateKeyInfo;
import org.bouncycastle.cbor.c509.C509CertificationRequestTemplate;
import org.bouncycastle.cbor.c509.C509MediaTypes;
import org.bouncycastle.cert.X509CRLHolder;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cmc.CMCException;
import org.bouncycastle.cmc.SimplePKIResponse;
import org.bouncycastle.mime.BasicMimeParser;
import org.bouncycastle.mime.ConstantMimeContext;
import org.bouncycastle.mime.Headers;
import org.bouncycastle.mime.MimeContext;
import org.bouncycastle.mime.MimeParser;
import org.bouncycastle.mime.MimeParserContext;
import org.bouncycastle.mime.MimeParserListener;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.pkcs.PKCS10CertificationRequest;
import org.bouncycastle.pkcs.PKCS10CertificationRequestBuilder;
import org.bouncycastle.util.Exceptions;
import org.bouncycastle.util.Selector;
import org.bouncycastle.util.Store;
import org.bouncycastle.util.encoders.Base64;
import org.bouncycastle.util.io.Streams;

/**
 * ESTService provides unified access to an EST server which is defined as implementing
 * RFC7030.
 */
public class ESTService
{
    protected static final String CACERTS = "/cacerts";
    protected static final String SIMPLE_ENROLL = "/simpleenroll";
    protected static final String SIMPLE_REENROLL = "/simplereenroll";
    protected static final String FULLCMC = "/fullcmc";
    protected static final String SERVERGEN = "/serverkeygen";
    protected static final String CSRATTRS = "/csrattrs";

    /**
     * Upper bound on the size of a C509 certification request template response -
     * generous for a structure that lists attribute types and short prescribed values.
     */
    private static final int MAX_C509_TEMPLATE_SIZE = 1024 * 1024;

    protected static final Set<String> illegalParts = new HashSet<String>();

    static
    {
        illegalParts.add(CACERTS.substring(1));
        illegalParts.add(SIMPLE_ENROLL.substring(1));
        illegalParts.add(SIMPLE_REENROLL.substring(1));
        illegalParts.add(FULLCMC.substring(1));
        illegalParts.add(SERVERGEN.substring(1));
        illegalParts.add(CSRATTRS.substring(1));
    }


    private final String server;
    private final ESTClientProvider clientProvider;

    private static final Pattern pathInValid = Pattern.compile("^[0-9a-zA-Z_\\-.~!$&'()*+,;:=]+");

    ESTService(
        String serverAuthority, String label,
        ESTClientProvider clientProvider)
    {

        serverAuthority = verifyServer(serverAuthority);

        if (label != null)
        {
            label = verifyLabel(label);
            server = "https://" + serverAuthority + "/.well-known/est/" + label;
        }
        else
        {
            server = "https://" + serverAuthority + "/.well-known/est";
        }

        this.clientProvider = clientProvider;
    }

    /**
     * Utility method to extract all the X509Certificates from a store and return them in an array.
     *
     * @param store The store.
     * @return An arrar of certificates/
     */
    public static X509CertificateHolder[] storeToArray(Store<X509CertificateHolder> store)
    {
        return storeToArray(store, null);
    }

    /**
     * Utility method to extract all the X509Certificates from a store using a filter and to return them
     * as an array.
     *
     * @param store    The store.
     * @param selector The selector.
     * @return An array of X509Certificates.
     */
    public static X509CertificateHolder[] storeToArray(Store<X509CertificateHolder> store, Selector<X509CertificateHolder> selector)
    {
        Collection<X509CertificateHolder> c = store.getMatches(selector);
        return c.toArray(new X509CertificateHolder[c.size()]);
    }

    /**
     * Query the EST server for ca certificates.
     * <p>
     * RFC7030 leans heavily on the verification phases of TLS for both client and server verification.
     * <p>
     * It does however define a bootstrapping mode where if the client does not have the necessary ca certificates to
     * validate the server it can defer to an external source, such as a human, to formally accept the ca certs.
     * <p>
     * If callers are using bootstrapping they must examine the CACertsResponse and validate it externally.
     *
     * @return A store of X509Certificates.
     */
    public CACertsResponse getCACerts()
        throws ESTException
    {
        ESTResponse resp = null;
        Exception finalThrowable = null;
        CACertsResponse caCertsResponse = null;
        URL url = null;
        boolean failedBeforeClose = false;
        try
        {
            url = new URL(server + CACERTS);

            ESTClient client = clientProvider.makeClient();
            ESTRequest req = new ESTRequestBuilder("GET", url).withClient(client).build();
            resp = client.doRequest(req);

            Store<X509CertificateHolder> caCerts = null;
            Store<X509CRLHolder> crlHolderStore = null;

            if (resp.getStatusCode() == 200)
            {
                String contentType = resp.getHeaders().getFirstValue("Content-Type");
                if (contentType == null || !contentType.startsWith("application/pkcs7-mime"))
                {
                    String j = contentType != null ? " got " + contentType : " but was not present.";
                    throw new ESTException(("Response : " + url.toString() + "Expecting application/pkcs7-mime ") + j, null, resp.getStatusCode(), resp.getInputStream());
                }

                try
                {
                    ASN1InputStream ain = getASN1InputStream(resp.getInputStream(), resp.getContentLength());

                    SimplePKIResponse spkr = new SimplePKIResponse(ContentInfo.getInstance(ain.readObject()));
                    caCerts = spkr.getCertificates();
                    crlHolderStore = spkr.getCRLs();
                }
                catch (Throwable ex)
                {
                    throw new ESTException("Decoding CACerts: " + url.toString() + " " + ex.getMessage(), ex, resp.getStatusCode(), resp.getInputStream());
                }

            }
            else if (resp.getStatusCode() != 204) // 204 are No Content
            {
                throw new ESTException("Get CACerts: " + url.toString(), null, resp.getStatusCode(), resp.getInputStream());
            }

            caCertsResponse = new CACertsResponse(caCerts, crlHolderStore, req, resp.getSource(), clientProvider.isTrusted());

        }
        catch (Throwable t)
        {
            failedBeforeClose = true;
            if (t instanceof ESTException)
            {
                throw (ESTException)t;
            }
            else
            {
                throw new ESTException(t.getMessage(), t);
            }
        }
        finally
        {
            if (resp != null)
            {
                try
                {
                    resp.close();
                }
                catch (Exception t)
                {
                    finalThrowable = t;
                }
            }
        }

        if (finalThrowable != null)
        {
            if (finalThrowable instanceof ESTException)
            {
                throw (ESTException)finalThrowable;
            }
            throw new ESTException("Get CACerts: " + url.toString(), finalThrowable, resp.getStatusCode(), null);
        }

        return caCertsResponse;
    }

    private ASN1InputStream getASN1InputStream(InputStream respStream, Long contentLength)
    {
        if (contentLength == null)
        {
            return new ASN1InputStream(respStream);
        }

        if (contentLength.intValue() == contentLength.longValue())
        {
            return new ASN1InputStream(respStream, contentLength.intValue());
        }

        return new ASN1InputStream(respStream);
    }

    /**
     * Reissue an existing request where the server had previously returned a 202.
     *
     * @param priorResponse The prior response.
     * @return A new ESTEnrollmentResponse
     * @throws Exception
     */
    public EnrollmentResponse simpleEnroll(EnrollmentResponse priorResponse)
        throws Exception
    {
        if (!clientProvider.isTrusted())
        {
            throw new IllegalStateException("No trust anchors.");
        }

        ESTResponse resp = null;

        try
        {
            ESTClient client = clientProvider.makeClient();
            resp = client.doRequest(new ESTRequestBuilder(priorResponse.getRequestToRetry()).withClient(client).build());
            return handleEnrollResponse(resp);
        }
        catch (Throwable t)
        {
            if (t instanceof ESTException)
            {
                throw (ESTException)t;
            }
            else
            {
                throw new ESTException(t.getMessage(), t);
            }
        }
        finally
        {
            if (resp != null)
            {
                resp.close();
            }
        }
    }

    /**
     * Perform a simple enrollment operation.
     * <p>
     * This method accepts an ESPHttpAuth instance to provide basic or digest authentication.
     * <p>
     * If authentication is to be performed as part of TLS then this instances client keystore and their keystore
     * password need to be specified.
     *
     * @param certificationRequest The certification request.
     * @param auth                 The http auth provider, basic auth or digest auth, can be null.
     * @param certGen              if true, request server key generation
     * @return The enrolled certificate.
     */
    protected EnrollmentResponse enroll(
        boolean reenroll,
        PKCS10CertificationRequest certificationRequest,
        ESTAuth auth,
        boolean certGen)
        throws IOException
    {
        if (!clientProvider.isTrusted())
        {
            throw new IllegalStateException("No trust anchors.");
        }

        ESTResponse resp = null;
        try
        {
            final byte[] data = annotateRequest(certificationRequest.getEncoded()).getBytes();

            URL url = new URL(server + (certGen ? SERVERGEN : (reenroll ? SIMPLE_REENROLL : SIMPLE_ENROLL)));


            ESTClient client = clientProvider.makeClient();
            ESTRequestBuilder req = new ESTRequestBuilder("POST", url).withData(data).withClient(client);

            req.addHeader("Content-Type", "application/pkcs10");
            req.addHeader("Content-Length", "" + data.length);
            req.addHeader("Content-Transfer-Encoding", "base64");

            if (auth != null)
            {
                auth.applyAuth(req);
            }

            resp = client.doRequest(req.build());

            return handleEnrollResponse(resp);

        }
        catch (Throwable t)
        {
            if (t instanceof ESTException)
            {
                throw (ESTException)t;
            }
            else
            {
                throw new ESTException(t.getMessage(), t);
            }
        }
        finally
        {
            if (resp != null)
            {
                resp.close();
            }
        }

    }


    /**
     * Perform a simple enrollment operation.
     * <p>
     * This method accepts an ESPHttpAuth instance to provide basic or digest authentication.
     * <p>
     * If authentication is to be performed as part of TLS then this instances client keystore and their keystore
     * password need to be specified.
     *
     * @param reenroll             true for enrollment.
     * @param certificationRequest The certification request.
     * @param auth                 The http auth provider, basic auth or digest auth, can be null.
     * @return The enrolled certificate.
     */
    public EnrollmentResponse simpleEnroll(boolean reenroll, PKCS10CertificationRequest certificationRequest, ESTAuth auth)
        throws IOException
    {
        return enroll(reenroll, certificationRequest, auth, false);
    }


    /**
     * Perform a simple enrollment operation.
     * <p>
     * This method accepts an ESPHttpAuth instance to provide basic or digest authentication.
     * <p>
     * If authentication is to be performed as part of TLS then this instances client keystore and their keystore
     * password need to be specified.
     *
     * @param certificationRequest The certification request.
     * @param auth                 The http auth provider, basic auth or digest auth, can be null.
     * @return The enrolled certificate.
     */
    public EnrollmentResponse simpleEnrollWithServersideCreation(PKCS10CertificationRequest certificationRequest, ESTAuth auth)
        throws IOException
    {
        return enroll(false, certificationRequest, auth, true);
    }


    /**
     * Implements Enroll with PoP.
     * Request will have the tls-unique attribute added to it before it is signed and completed.
     *
     * @param reEnroll      True = re enroll.
     * @param builder       The request builder.
     * @param contentSigner The content signer.
     * @param auth          Auth modes.
     * @param certGen       if true will request server key generation.
     * @return Enrollment response.
     * @throws IOException
     */
    public EnrollmentResponse enrollPop(
        boolean reEnroll,
        final PKCS10CertificationRequestBuilder builder,
        final ContentSigner contentSigner,
        ESTAuth auth, boolean certGen)
        throws IOException
    {
        return enrollPop(reEnroll, builder, contentSigner, auth, certGen, null);
    }

    /**
     * Implements Enroll with PoP and RFC 7894-aware tls-unique attribute selection.
     * <p>
     * When {@code csrAttrs} advertises {@link PKCSObjectIdentifiers#id_aa_estIdentityLinking}
     * the tls-unique value is conveyed in an {@code id-aa-estIdentityLinking}
     * attribute (RFC 7894 §3.3 / §4); otherwise the legacy
     * {@code pkcs_9_at_challengePassword} attribute is used (RFC 7030 §3.5).
     * </p>
     *
     * @param reEnroll      True = re enroll.
     * @param builder       The request builder.
     * @param contentSigner The content signer.
     * @param auth          Auth modes.
     * @param certGen       if true will request server key generation.
     * @param csrAttrs      the CSR-Attributes response previously fetched from the
     *                      server, or {@code null} if none is available.
     * @return Enrollment response.
     * @throws IOException
     */
    public EnrollmentResponse enrollPop(
        boolean reEnroll,
        final PKCS10CertificationRequestBuilder builder,
        final ContentSigner contentSigner,
        ESTAuth auth, boolean certGen,
        final CSRAttributesResponse csrAttrs)
        throws IOException
    {
        if (!clientProvider.isTrusted())
        {
            throw new IllegalStateException("No trust anchors.");
        }

        ESTResponse resp = null;
        try
        {
            URL url = new URL(server + (reEnroll ? SIMPLE_REENROLL : SIMPLE_ENROLL));
            ESTClient client = clientProvider.makeClient();

            //
            // Connect supplying a source listener.
            // The source listener is responsible for completing the PCS10 Cert request and encoding it.
            //
            ESTRequestBuilder reqBldr = new ESTRequestBuilder("POST", url).withClient(client).withConnectionListener(new ESTSourceConnectionListener()
            {
                public ESTRequest onConnection(Source source, ESTRequest request)
                    throws IOException
                {
                    //
                    // Add the tls-unique value either as estIdentityLinking (RFC 7894)
                    // or as the legacy challengePassword (RFC 7030 §3.5), per the
                    // CSR-Attributes response.
                    //

                    if (source instanceof TLSUniqueProvider && ((TLSUniqueProvider)source).isTLSUniqueAvailable())
                    {
                        PKCS10CertificationRequestBuilder localBuilder = new PKCS10CertificationRequestBuilder(builder);

                        ByteArrayOutputStream bos = new ByteArrayOutputStream();
                        byte[] tlsUnique = ((TLSUniqueProvider)source).getTLSUnique();

                        TlsUniqueAttributeUtil.setTlsUniqueAttribute(localBuilder, tlsUnique, csrAttrs);
                        bos.write(annotateRequest(localBuilder.build(contentSigner).getEncoded()).getBytes());
                        bos.flush();

                        ESTRequestBuilder reqBuilder = new ESTRequestBuilder(request).withData(bos.toByteArray());

                        reqBuilder.setHeader("Content-Type", "application/pkcs10");
                        reqBuilder.setHeader("Content-Transfer-Encoding", "base64");
                        reqBuilder.setHeader("Content-Length", Long.toString(bos.size()));

                        return reqBuilder.build();
                    }
                    else
                    {
                        throw new IOException("Source does not supply TLS unique.");
                    }
                }
            });

            if (auth != null)
            {
                auth.applyAuth(reqBldr);
            }

            resp = client.doRequest(reqBldr.build());

            return handleEnrollResponse(resp);

        }
        catch (Throwable t)
        {
            if (t instanceof ESTException)
            {
                throw (ESTException)t;
            }
            else
            {
                throw new ESTException(t.getMessage(), t);
            }
        }
        finally
        {
            if (resp != null)
            {
                resp.close();
            }
        }

    }


    /**
     * Implements Enroll with PoP.
     * Request will have the tls-unique attribute added to it before it is signed and completed.
     *
     * @param reEnroll      True = re enroll.
     * @param builder       The request builder.
     * @param contentSigner The content signer.
     * @param auth          Auth modes.
     * @return Enrollment response.
     * @throws IOException
     */
    public EnrollmentResponse simpleEnrollPoP(boolean reEnroll, final PKCS10CertificationRequestBuilder builder, final ContentSigner contentSigner, ESTAuth auth)
        throws IOException
    {
        return enrollPop(reEnroll, builder, contentSigner, auth, false, null);
    }

    /**
     * Simple enrollment with PoP and RFC 7894-aware tls-unique attribute selection.
     *
     * @param reEnroll      True = re enroll.
     * @param builder       The request builder.
     * @param contentSigner The content signer.
     * @param auth          Auth modes.
     * @param csrAttrs      the CSR-Attributes response previously fetched from the
     *                      server, or {@code null} for the legacy
     *                      {@code challengePassword} attribute.
     * @return Enrollment response.
     * @throws IOException
     */
    public EnrollmentResponse simpleEnrollPoP(
        boolean reEnroll,
        final PKCS10CertificationRequestBuilder builder,
        final ContentSigner contentSigner,
        ESTAuth auth,
        CSRAttributesResponse csrAttrs)
        throws IOException
    {
        return enrollPop(reEnroll, builder, contentSigner, auth, false, csrAttrs);
    }


    /**
     * Simple enrollment with PoP and server side creation of keys.
     *
     * @param builder       The request builder.
     * @param contentSigner The content signer
     * @param auth          Auth modes
     * @return Enrollment Response
     * @throws IOException
     */
    public EnrollmentResponse simpleEnrollPopWithServersideCreation(
        final PKCS10CertificationRequestBuilder builder,
        final ContentSigner contentSigner,
        ESTAuth auth)
        throws IOException
    {
        return enrollPop(false, builder, contentSigner, auth, true, null);
    }

    /**
     * Simple enrollment with PoP, server-side key creation, and RFC 7894-aware
     * tls-unique attribute selection.
     *
     * @param builder       The request builder.
     * @param contentSigner The content signer.
     * @param auth          Auth modes.
     * @param csrAttrs      the CSR-Attributes response previously fetched from the
     *                      server, or {@code null} for the legacy
     *                      {@code challengePassword} attribute.
     * @return Enrollment response.
     * @throws IOException
     */
    public EnrollmentResponse simpleEnrollPopWithServersideCreation(
        final PKCS10CertificationRequestBuilder builder,
        final ContentSigner contentSigner,
        ESTAuth auth,
        CSRAttributesResponse csrAttrs)
        throws IOException
    {
        return enrollPop(false, builder, contentSigner, auth, true, csrAttrs);
    }


    /**
     * Handles an enrollment response, deals with status codes and setting of delays.
     *
     * @param resp The response.
     * @return An EnrollmentResponse.
     * @throws IOException
     */
    protected EnrollmentResponse handleEnrollResponse(ESTResponse resp)
        throws IOException
    {

        ESTRequest req = resp.getOriginalRequest();
        Store<X509CertificateHolder> enrolled = null;
        if (resp.getStatusCode() == 202)
        {
            // Received but not ready.
            String rt = resp.getHeader("Retry-After");

            if (rt == null)
            {
                throw new ESTException("Got Status 202 but not Retry-After header from: " + req.getURL().toString());
            }

            long notBefore = -1;


            try
            {
                notBefore = System.currentTimeMillis() + (Long.parseLong(rt) * 1000);
            }
            catch (NumberFormatException nfe)
            {
                try
                {
                    SimpleDateFormat dateFormat = new SimpleDateFormat(
                        "EEE, dd MMM yyyy HH:mm:ss z", Locale.US);
                    dateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
                    notBefore = dateFormat.parse(rt).getTime();
                }
                catch (Exception ex)
                {
                    throw new ESTException(
                        "Unable to parse Retry-After header:" + req.getURL().toString() + " " + ex.getMessage(), null,
                        resp.getStatusCode(), resp.getInputStream());
                }
            }

            return new EnrollmentResponse(null, notBefore, req, resp.getSource());

        }
        else if (resp.getStatusCode() == 200 && resp.getHeaderOrEmpty("content-type").contains("multipart/mixed"))
        {

            Headers mimeHeaders = new Headers(resp.getHeaderOrEmpty("content-type"), "base64");
            MimeParser mp = new BasicMimeParser(mimeHeaders, resp.getInputStream());

            // 0 = PrivateKeyInfo, 1 = SimplePKIResponse
            final Object[] parts = new Object[2];

            mp.parse(new MimeParserListener()
            {
                public MimeContext createContext(MimeParserContext parserContext, Headers headers)
                {
                    return ConstantMimeContext.Instance;
                }

                public void object(MimeParserContext parserContext, Headers headers, InputStream inputStream)
                    throws IOException
                {
                    if (headers.getContentType().contains("application/pkcs8"))
                    {
                        ASN1InputStream asn1In = new ASN1InputStream(inputStream);
                        parts[0] = PrivateKeyInfo.getInstance(asn1In.readObject());

                        // We want to check we got what we expected in terms of responses,
                        // and nothing more.
                        if (asn1In.readObject() != null)
                        {
                            throw new ESTException("Unexpected ASN1 object after private key info");
                        }

                    }
                    else if (headers.getContentType().contains("application/pkcs7-mime"))
                    {
                        ASN1InputStream asn1In = new ASN1InputStream(inputStream);
                        try
                        {
                            parts[1] = new SimplePKIResponse(ContentInfo.getInstance(asn1In.readObject()));
                        }
                        catch (CMCException e)
                        {
                            throw Exceptions.ioException(e.getMessage(), e);
                        }

                        // We want to check we got what we expected in terms of responses,
                        // and nothing more.
                        if (asn1In.readObject() != null)
                        {
                            throw new ESTException("Unexpected ASN1 object after reading certificates");
                        }
                    }
                }
            });

            if (parts[0] == null || parts[1] == null)
            {
                throw new ESTException("received neither private key info and certificates");
            }

            enrolled = ((SimplePKIResponse)parts[1]).getCertificates();
            return new EnrollmentResponse(enrolled, -1, null, resp.getSource(), PrivateKeyInfo.getInstance(parts[0]));


        }
        else if (resp.getStatusCode() == 200)
        {
            ASN1InputStream ain = new ASN1InputStream(resp.getInputStream());
            SimplePKIResponse spkr = null;
            try
            {
                spkr = new SimplePKIResponse(ContentInfo.getInstance(ain.readObject()));
            }
            catch (CMCException e)
            {
                throw new ESTException(e.getMessage(), e.getCause());
            }
            enrolled = spkr.getCertificates();
            return new EnrollmentResponse(enrolled, -1, null, resp.getSource());
        }

        throw new ESTException(
            "Simple Enroll: " + req.getURL().toString(), null,
            resp.getStatusCode(), resp.getInputStream());

    }

    /**
     * Fetch he CSR Attributes from the server.
     *
     * @return A CSRRequestResponse with the attributes.
     * @throws ESTException
     */
    public CSRRequestResponse getCSRAttributes()
        throws ESTException
    {

        if (!clientProvider.isTrusted())
        {
            throw new IllegalStateException("No trust anchors.");
        }

        ESTResponse resp = null;
        CSRAttributesResponse response = null;
        Exception finalThrowable = null;
        // Set once the HTTP status alone determines the result and the body is irrelevant
        // (RFC 7030 sec. 4.5: 204 / 404). A failure while tidying up the connection must not
        // then be promoted into the caller's result and mask the real status (github #781).
        boolean outcomeFinal = false;
        URL url = null;
        try
        {
            url = new URL(server + CSRATTRS);

            ESTClient client = clientProvider.makeClient();
            ESTRequest req = new ESTRequestBuilder("GET", url).withClient(client).build(); //    new ESTRequest("GET", url, null);
            resp = client.doRequest(req);


            switch (resp.getStatusCode())
            {
            case 200:
                try
                {
                    ASN1InputStream ain = getASN1InputStream(resp.getInputStream(), resp.getContentLength());
                    ASN1Sequence seq = ASN1Sequence.getInstance(ain.readObject());
                    response = new CSRAttributesResponse(CsrAttrs.getInstance(seq));
                }
                catch (Throwable ex)
                {
                    throw new ESTException("Decoding CACerts: " + url.toString() + " " + ex.getMessage(), ex, resp.getStatusCode(), resp.getInputStream());
                }

                break;
            case 204:
            case 404:
                // RFC 7030 sec. 4.5: a 204 has no body and a 404 SHOULD be empty. Some servers
                // nevertheless attach an error body (e.g. a JSON message) to a 404. Drain it so the
                // resp.close() in the finally block does not trip one of the counter stream's guards
                // and obscure the actual status with a useless wrapper exception (github #781).
                //
                // The drain is never EOF-seeking: the counter stream has no Content-Length stop of
                // its own, so on a kept-alive HTTP/1.1 connection whose socket never signals EOF
                // (and no SO_TIMEOUT by default) reading until EOF would hang the calling thread.
                drainErrorBody(resp);
                response = null;
                // The status alone is the answer now - see outcomeFinal above.
                outcomeFinal = true;
                break;
            default:
                throw new ESTException(
                    "CSR Attribute request: " + req.getURL().toString(), null,
                    resp.getStatusCode(), resp.getInputStream());
            }
        }
        catch (Throwable t)
        {

            if (t instanceof ESTException)
            {
                throw (ESTException)t;
            }
            else
            {
                throw new ESTException(t.getMessage(), t);
            }
        }
        finally
        {
            if (resp != null)
            {
                try
                {
                    resp.close();
                }
                catch (Exception ex)
                {
                    // Only a close() failure that could still change the answer is promoted; for a
                    // 204/404 the result is already settled, so swallowing it here is what stops a
                    // tidy-up problem masking the real status.
                    if (!outcomeFinal)
                    {
                        finalThrowable = ex;
                    }
                }
            }
        }

        if (finalThrowable != null)
        {
            if (finalThrowable instanceof ESTException)
            {
                throw (ESTException)finalThrowable;
            }
            throw new ESTException(finalThrowable.getMessage(), finalThrowable, resp.getStatusCode(), null);
        }

        return new CSRRequestResponse(response, resp.getSource());
    }

    /**
     * Request the C509 certification request template for this client (Section 4.4 of
     * draft-ietf-cose-cbor-encoded-cert-21): a GET of /csrattrs asking for the
     * application/cose-c509-crtemplate+cbor media type. A server with a template for
     * this client returns it with that content type; as with the RFC 7030 form, a 204
     * or 404 means no template is available. A 200 carrying any other content type
     * (for example a legacy RFC 7030 csrattrs answer from a server that does not
     * support C509) is reported as an ESTException - use {@link #getCSRAttributes()}
     * against such a server.
     *
     * @return an object carrying the template, or the absence of one.
     */
    public C509CSRTemplateResponse getC509CertificationRequestTemplate()
        throws ESTException
    {
        if (!clientProvider.isTrusted())
        {
            throw new IllegalStateException("No trust anchors.");
        }

        ESTResponse resp = null;
        C509CertificationRequestTemplate template = null;
        Exception finalThrowable = null;
        // Set once the HTTP status alone determines the result and the body is irrelevant
        // (RFC 7030 sec. 4.5: 204 / 404) - see getCSRAttributes().
        boolean outcomeFinal = false;
        URL url = null;
        try
        {
            url = new URL(server + CSRATTRS);

            ESTClient client = clientProvider.makeClient();
            ESTRequest req = new ESTRequestBuilder("GET", url).withClient(client)
                .setHeader("Accept", C509MediaTypes.CERTIFICATION_REQUEST_TEMPLATE).build();
            resp = client.doRequest(req);

            switch (resp.getStatusCode())
            {
            case 200:
                try
                {
                    String contentType = resp.getHeaderOrEmpty("Content-Type");
                    if (!contentType.equals(C509MediaTypes.CERTIFICATION_REQUEST_TEMPLATE)
                        && !contentType.startsWith(C509MediaTypes.CERTIFICATION_REQUEST_TEMPLATE + ";"))
                    {
                        throw new ESTException("Response did not carry "
                            + C509MediaTypes.CERTIFICATION_REQUEST_TEMPLATE + ": " + contentType, null,
                            resp.getStatusCode(), resp.getInputStream());
                    }
                    // a template is a small structure; the read is bounded regardless of
                    // what content length the server declares
                    byte[] encoding = Streams.readAllLimited(resp.getInputStream(), MAX_C509_TEMPLATE_SIZE);
                    template = C509CertificationRequestTemplate.getInstance(encoding);
                }
                catch (Throwable ex)
                {
                    throw new ESTException("Decoding C509 CSR template: " + url.toString() + " " + ex.getMessage(),
                        ex, resp.getStatusCode(), resp.getInputStream());
                }

                break;
            case 204:
            case 404:
                // as in getCSRAttributes(): drain any error body a server wrongly attached,
                // and make the status the final answer (github #781)
                drainErrorBody(resp);
                template = null;
                outcomeFinal = true;
                break;
            default:
                throw new ESTException(
                    "CSR Template request: " + req.getURL().toString(), null,
                    resp.getStatusCode(), resp.getInputStream());
            }
        }
        catch (Throwable t)
        {
            if (t instanceof ESTException)
            {
                throw (ESTException)t;
            }
            else
            {
                throw new ESTException(t.getMessage(), t);
            }
        }
        finally
        {
            if (resp != null)
            {
                try
                {
                    resp.close();
                }
                catch (Exception ex)
                {
                    if (!outcomeFinal)
                    {
                        finalThrowable = ex;
                    }
                }
            }
        }

        if (finalThrowable != null)
        {
            if (finalThrowable instanceof ESTException)
            {
                throw (ESTException)finalThrowable;
            }
            throw new ESTException(finalThrowable.getMessage(), finalThrowable, resp.getStatusCode(), null);
        }

        return new C509CSRTemplateResponse(template, resp.getSource());
    }

    /**
     * Drain a 204/404 error body so the following close() does not trip the counter stream's
     * "Stream closed before limit fully read" check. Reads exactly the declared Content-Length and
     * never seeks EOF: the counter stream has no Content-Length stop of its own, so on a kept-alive
     * HTTP/1.1 connection whose socket never signals EOF (and no SO_TIMEOUT by default) reading
     * until EOF would hang the calling thread.
     * <p>
     * A response with no Content-Length is deliberately left alone. The only way to reach here
     * without one is a chunked body - anything else is rejected earlier by ESTResponse - and for
     * chunked ESTResponse has already normalised its content length to zero, which makes that check
     * inert ({@code 0 - 1 > read} is false for any read). Its other check, on bytes still in the
     * pipe, cannot be satisfied from here: the counter stream does not override available(), so a
     * drain sees zero while close() consults the underlying stream. That mismatch is why the
     * caller marks the outcome final instead of trying to drain its way to a quiet close.
     */
    private static void drainErrorBody(ESTResponse resp)
        throws IOException
    {
        Long bodyLength = resp.getContentLength();
        if (bodyLength == null)
        {
            return;
        }

        InputStream in = resp.getInputStream();
        byte[] buf = new byte[1024];
        long remaining = bodyLength.longValue();
        while (remaining > 0)
        {
            int rd = in.read(buf, 0, (int)Math.min(buf.length, remaining));
            if (rd < 0)
            {
                break;
            }
            remaining -= rd;
        }
    }

    private String annotateRequest(byte[] data)
    {
        int i = 0;
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        // pw.print("-----BEGIN CERTIFICATE REQUEST-----\n");
        do
        {
            // -DM Base64.toBase64String
            // -DM Base64.toBase64String
            if (i + 48 < data.length)
            {
                pw.print(Base64.toBase64String(data, i, 48));
                i += 48;
            }
            else
            {
                pw.print(Base64.toBase64String(data, i, data.length - i));
                i = data.length;
            }
            pw.print('\n');
        }
        while (i < data.length);
        //  pw.print("-----END CERTIFICATE REQUEST-----\n");
        pw.flush();
        return sw.toString();
    }


    private String verifyLabel(String label)
    {
        while (label.endsWith("/") && label.length() > 0)
        {
            label = label.substring(0, label.length() - 1);
        }

        while (label.startsWith("/") && label.length() > 0)
        {
            label = label.substring(1);
        }

        if (label.length() == 0)
        {
            throw new IllegalArgumentException("Label set but after trimming '/' is not zero length string.");
        }

        if (!pathInValid.matcher(label).matches())
        {
            throw new IllegalArgumentException("Server path " + label + " contains invalid characters");
        }

        if (illegalParts.contains(label))
        {
            throw new IllegalArgumentException("Label " + label + " is a reserved path segment.");
        }

        return label;

    }


    private String verifyServer(String server)
    {
        try
        {

            while (server.endsWith("/") && server.length() > 0)
            {
                server = server.substring(0, server.length() - 1);
            }

            if (server.contains("://"))
            {
                throw new IllegalArgumentException("Server contains scheme, must only be <dnsname/ipaddress>:port, https:// will be added arbitrarily.");
            }

            URL u = new URL("https://" + server);
            if (u.getPath().length() == 0 || u.getPath().equals("/"))
            {
                return server;
            }

            throw new IllegalArgumentException("Server contains path, must only be <dnsname/ipaddress>:port, a path of '/.well-known/est/<label>' will be added arbitrarily.");

        }
        catch (Exception ex)
        {
            if (ex instanceof IllegalArgumentException)
            {
                throw (IllegalArgumentException)ex;
            }
            throw new IllegalArgumentException("Scheme and host is invalid: " + ex.getMessage(), ex);
        }

    }

}
