package org.bouncycastle.asn1.cms;

import java.io.IOException;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.ASN1SequenceParser;
import org.bouncycastle.asn1.ASN1TaggedObjectParser;
import org.bouncycastle.asn1.ASN1Util;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

/**
 * Parser for <a href="https://tools.ietf.org/html/rfc5652#section-6.1">RFC 5652</a> EncryptedContentInfo object.
 * <p>
 * <pre>
 * EncryptedContentInfo ::= SEQUENCE {
 *     contentType ContentType,
 *     contentEncryptionAlgorithm ContentEncryptionAlgorithmIdentifier,
 *     encryptedContent [0] IMPLICIT EncryptedContent OPTIONAL
 * }
 * </pre>
 */
public class EncryptedContentInfoParser
{
    private ASN1ObjectIdentifier    _contentType;
    private AlgorithmIdentifier     _contentEncryptionAlgorithm;
    private ASN1TaggedObjectParser _encryptedContent;

    public EncryptedContentInfoParser(
        ASN1SequenceParser  seq)
        throws IOException
    {
        _contentType = (ASN1ObjectIdentifier)seq.readObject();
        if (_contentType == null)
        {
            throw new IOException("EncryptedContentInfo missing contentType");
        }

        ASN1Encodable alg = seq.readObject();
        if (alg == null)
        {
            throw new IOException("EncryptedContentInfo missing contentEncryptionAlgorithm");
        }

        _contentEncryptionAlgorithm = AlgorithmIdentifier.getInstance(alg.toASN1Primitive());
        ASN1Encodable next = seq.readObject();
        if (next != null && !(next instanceof ASN1TaggedObjectParser))
        {
            throw new IOException("EncryptedContentInfo has an unexpected element where encryptedContent [0] is expected");
        }
        _encryptedContent = (ASN1TaggedObjectParser)next;
    }

    public ASN1ObjectIdentifier getContentType()
    {
        return _contentType;
    }

    public AlgorithmIdentifier getContentEncryptionAlgorithm()
    {
        return _contentEncryptionAlgorithm;
    }

    public ASN1Encodable getEncryptedContent(
        int  tag)
        throws IOException
    {
        if (_encryptedContent == null)
        {
            return null;
        }

        return ASN1Util.parseContextBaseUniversal(_encryptedContent, 0, false, tag);
    }
}
