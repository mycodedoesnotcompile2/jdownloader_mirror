package org.bouncycastle.asn1.cms;

import java.io.IOException;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1Integer;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1OctetStringParser;
import org.bouncycastle.asn1.ASN1SequenceParser;
import org.bouncycastle.asn1.ASN1SetParser;
import org.bouncycastle.asn1.ASN1TaggedObjectParser;
import org.bouncycastle.asn1.ASN1Util;
import org.bouncycastle.asn1.BERTags;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

/**
 * Parse {@link AuthenticatedData} stream.
 * <pre>
 * AuthenticatedData ::= SEQUENCE {
 *       version CMSVersion,
 *       originatorInfo [0] IMPLICIT OriginatorInfo OPTIONAL,
 *       recipientInfos RecipientInfos,
 *       macAlgorithm MessageAuthenticationCodeAlgorithm,
 *       digestAlgorithm [1] DigestAlgorithmIdentifier OPTIONAL,
 *       encapContentInfo EncapsulatedContentInfo,
 *       authAttrs [2] IMPLICIT AuthAttributes OPTIONAL,
 *       mac MessageAuthenticationCode,
 *       unauthAttrs [3] IMPLICIT UnauthAttributes OPTIONAL }
 *
 * AuthAttributes ::= SET SIZE (1..MAX) OF Attribute
 *
 * UnauthAttributes ::= SET SIZE (1..MAX) OF Attribute
 *
 * MessageAuthenticationCode ::= OCTET STRING
 * </pre>
 */
public class AuthenticatedDataParser
{
    private ASN1SequenceParser seq;
    private ASN1Integer version;
    private ASN1Encodable nextObject;
    private boolean originatorInfoCalled;

    public AuthenticatedDataParser(
        ASN1SequenceParser seq)
        throws IOException
    {
        this.seq = seq;
        this.version = ASN1Integer.getInstance(seq.readObject());
        if (version == null)
        {
            throw new IOException("AuthenticatedData missing version");
        }
    }

    public ASN1Integer getVersion()
    {
        return version;
    }

    public OriginatorInfo getOriginatorInfo()
        throws IOException
    {
        originatorInfoCalled = true;

        if (nextObject == null)
        {
            nextObject = seq.readObject();
        }

        if (nextObject instanceof ASN1TaggedObjectParser)
        {
            ASN1TaggedObjectParser o = (ASN1TaggedObjectParser)nextObject;
            if (o.hasContextTag(0))
            {
                ASN1SequenceParser originatorInfo = (ASN1SequenceParser)o.parseBaseUniversal(false, BERTags.SEQUENCE);
                nextObject = null;
                return OriginatorInfo.getInstance(originatorInfo.getLoadedObject());
            }
        }

        return null;
    }

    public ASN1SetParser getRecipientInfos()
        throws IOException
    {
        if (!originatorInfoCalled)
        {
            getOriginatorInfo();
        }

        if (nextObject == null)
        {
            nextObject = seq.readObject();
        }

        if (nextObject == null)
        {
            throw new IOException("AuthenticatedData missing recipientInfos");
        }

        ASN1SetParser recipientInfos = (ASN1SetParser)nextObject;
        nextObject = null;
        return recipientInfos;
    }

    public AlgorithmIdentifier getMacAlgorithm()
        throws IOException
    {
        if (nextObject == null)
        {
            nextObject = seq.readObject();
        }

        if (nextObject == null)
        {
            throw new IOException("AuthenticatedData missing macAlgorithm");
        }

        ASN1SequenceParser o = (ASN1SequenceParser)nextObject;
        nextObject = null;
        return AlgorithmIdentifier.getInstance(o.toASN1Primitive());
    }

    public AlgorithmIdentifier getDigestAlgorithm()
        throws IOException
    {
        if (nextObject == null)
        {
            nextObject = seq.readObject();
        }

        if (nextObject instanceof ASN1TaggedObjectParser)
        {
            ASN1TaggedObjectParser o = (ASN1TaggedObjectParser)nextObject;
            if (!o.hasContextTag(1))
            {
                throw new IOException("AuthenticatedData has an unexpected tag where digestAlgorithm [1] is expected: "
                    + ASN1Util.getTagText(o));
            }
            ASN1SequenceParser digestAlgorithm = (ASN1SequenceParser)o.parseBaseUniversal(false, BERTags.SEQUENCE);
            nextObject = null;
            return AlgorithmIdentifier.getInstance(digestAlgorithm.getLoadedObject());
        }

        return null;
    }

    public ContentInfoParser getEncapsulatedContentInfo()
        throws IOException
    {
        if (nextObject == null)
        {
            nextObject = seq.readObject();
        }

        if (nextObject == null)
        {
            throw new IOException("AuthenticatedData missing encapContentInfo");
        }

        ASN1SequenceParser o = (ASN1SequenceParser)nextObject;
        nextObject = null;
        return new ContentInfoParser(o);
    }

    public ASN1SetParser getAuthAttrs()
        throws IOException
    {
        if (nextObject == null)
        {
            nextObject = seq.readObject();
        }

        if (nextObject instanceof ASN1TaggedObjectParser)
        {
            ASN1TaggedObjectParser o = (ASN1TaggedObjectParser)nextObject;
            if (!o.hasContextTag(2))
            {
                throw new IOException("AuthenticatedData has an unexpected element after encapContentInfo");
            }
            nextObject = null;
            return (ASN1SetParser)ASN1Util.parseContextBaseUniversal(o, 2, false, BERTags.SET_OF);
        }

        return null;
    }

    public ASN1OctetString getMac()
        throws IOException
    {
        if (nextObject == null)
        {
            nextObject = seq.readObject();
        }

        if (nextObject == null)
        {
            throw new IOException("AuthenticatedData missing mac");
        }

        ASN1Encodable o = nextObject;
        nextObject = null;

        if (!(o instanceof ASN1OctetStringParser))
        {
            throw new IOException("AuthenticatedData mac is not an OCTET STRING");
        }

        return ASN1OctetString.getInstance(((ASN1OctetStringParser)o).getLoadedObject());
    }

    public ASN1SetParser getUnauthAttrs()
        throws IOException
    {
        if (nextObject == null)
        {
            nextObject = seq.readObject();
        }

        if (nextObject != null)
        {
            if (!(nextObject instanceof ASN1TaggedObjectParser) || !((ASN1TaggedObjectParser)nextObject).hasContextTag(3))
            {
                throw new IOException("AuthenticatedData has an unexpected element after mac");
            }
            ASN1TaggedObjectParser o = (ASN1TaggedObjectParser)nextObject;
            nextObject = null;
            ASN1SetParser unauthAttrs = (ASN1SetParser)ASN1Util.parseContextBaseUniversal(o, 3, false, BERTags.SET_OF);
            return new EndCheckedSetParser(unauthAttrs, seq, "AuthenticatedData", "unauthAttrs");
        }

        return null;
    }
}
