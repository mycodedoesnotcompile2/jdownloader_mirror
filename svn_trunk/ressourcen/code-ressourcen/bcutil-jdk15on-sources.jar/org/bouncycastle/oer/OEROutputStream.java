package org.bouncycastle.oer;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;

import org.bouncycastle.asn1.ASN1BitString;
import org.bouncycastle.asn1.ASN1Boolean;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1Enumerated;
import org.bouncycastle.asn1.ASN1IA5String;
import org.bouncycastle.asn1.ASN1Integer;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Primitive;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.ASN1UTF8String;
import org.bouncycastle.asn1.BERTags;
import org.bouncycastle.util.BigIntegers;
import org.bouncycastle.util.Longs;
import org.bouncycastle.util.Pack;
import org.bouncycastle.util.Strings;
import org.bouncycastle.util.encoders.Hex;

public class OEROutputStream
    extends OutputStream
{
    private final OutputStream out;
    protected PrintWriter debugOutput = null;

    public OEROutputStream(OutputStream out)
    {
        this.out = out;
    }

    /**
     * The number of octets {@code value} occupies as an unsigned big-endian number with no leading
     * zero octets: 0 for 0, 1 for 1..255, 2 for 256..65535, and 8 for any negative argument.
     */
    public static int byteLength(long value)
    {
        return (Longs.bitLength(value) + 7) >>> 3;
    }

    /**
     * Whether a SEQUENCE component is present on the wire, X.696 sec. 16.2.3: it is not an undefined
     * OEROptional (a defined one stands for its value), and, if the component has a DEFAULT, it
     * differs from that default - a value equal to its default is omitted, as CANONICAL-OER requires
     * (sec. 31.9, for root components and extension additions alike). The presence bitmaps and the
     * component values are all written from this, so they agree.
     */
    private static boolean isPresent(ASN1Encodable value, Element component)
    {
        if (value instanceof OEROptional)
        {
            OEROptional optional = (OEROptional)value;
            if (!optional.isDefined())
            {
                return false;
            }
            value = optional.get();
        }

        ASN1Encodable defaultValue = component.getDefaultValue();
        return defaultValue == null || !defaultValue.equals(value);
    }

    /**
     * Build a "call stack like" suffix identifying the offending element for diagnostic messages.
     * Returns the empty string when the child element has no label, so the existing message text is
     * preserved byte-for-byte for unlabelled elements.
     */
    private static String elementLabelSuffix(Element child, Element parent)
    {
        String childLabel = child == null ? null : child.getLabel();
        if (childLabel == null)
        {
            return "";
        }

        String parentLabel = parent == null ? null : parent.getLabel();
        if (parentLabel == null)
        {
            return ": " + childLabel;
        }

        return ": " + parentLabel + "." + childLabel;
    }

    public void write(ASN1Encodable encodable, Element oerElement)
        throws IOException
    {

        if (encodable == OEROptional.ABSENT)
        {
            return;
        }
        else if (encodable instanceof OEROptional)
        {
            write(((OEROptional)encodable).get(), oerElement);
            return;
        }

        //oerElement = Element.expandDeferredDefinition(oerElement, );

        encodable = encodable.toASN1Primitive();

        switch (oerElement.getBaseType())
        {

        case Supplier:
            write(encodable, oerElement.getElementSupplier().build());
            break;
        case SEQ:
        {
            ASN1Sequence seq = ASN1Sequence.getInstance(encodable);

            // build mask.
            int j = 7;
            int mask = 0;

            //
            // Does the extension bit in the preamble need to exist and does it need to be set?
            //
            boolean extensionDefined = false;
            if (oerElement.isExtensionsInDefinition())
            {
                for (int t = 0; t < oerElement.getChildren().size(); t++)
                {
                    Element e = oerElement.getChildren().get(t);
                    if (e.getBaseType() == OERDefinition.BaseType.EXTENSION)
                    {
                        break; // Can support extensions but doesn't have any defined.
                    }

                    if ((e.getBlock() > 0 && t < seq.size()))
                    {
                        if (isPresent(seq.getObjectAt(t), e))
                        {
                            // Can support extensions and one or more have been defined.
                            extensionDefined = true;
                            break;
                        }
                    }
                }

                if (extensionDefined)
                {
                    mask |= 1 << j;
                }
                j--;
            }

            //
            // Write optional bit mask for block 0.
            //
            for (int t = 0; t < oerElement.getChildren().size(); t++)
            {
                Element childOERDescription = oerElement.getChildren().get(t);
                if (childOERDescription.getBaseType() == OERDefinition.BaseType.EXTENSION)
                {
                    // We don't encode these, they are marker when the possibility of an extension is indicated but no actual extensions
                    // are defined as yet.
                    continue;
                }

                if (childOERDescription.getBlock() > 0)
                {
                    // We are heading into extensions now so stop here and write out the values
                    // for block 0.
                    break;
                }

                childOERDescription = Element.expandDeferredDefinition(childOERDescription, oerElement);
                if (oerElement.getaSwitch() != null)
                {
                    childOERDescription = oerElement.getaSwitch().result(new SwitchIndexer.Asn1SequenceIndexer(seq));
                    childOERDescription = Element.expandDeferredDefinition(childOERDescription, oerElement);
                }


                if (j < 0)
                {
                    out.write(mask);
                    j = 7;
                    mask = 0;
                }

                ASN1Encodable asn1EncodableChild = seq.getObjectAt(t);

                if (childOERDescription.isExplicit())
                {
                    // a required component may arrive wrapped in a defined OEROptional, which write()
                    // unwraps; only the undefined wrapper is an absence
                    if (asn1EncodableChild instanceof OEROptional && !((OEROptional)asn1EncodableChild).isDefined())
                    {
                        throw new IllegalStateException(
                            "absent sequence element that is required by oer definition"
                                + elementLabelSuffix(childOERDescription, oerElement));
                    }
                }
                else
                {
                    if (isPresent(asn1EncodableChild, childOERDescription))
                    {
                        mask |= 1 << j;
                    }
                    j--;
                }
            }

            if (j != 7)
            {
                out.write(mask);
            }


            List<Element> childElements = oerElement.getChildren();
            //
            // Write the values for block 0.
            //
            int t;
            for (t = 0; t < childElements.size(); t++)
            {
                Element childOERElement = oerElement.getChildren().get(t);

                if (childOERElement.getBaseType() == OERDefinition.BaseType.EXTENSION)
                {
                    continue;
                }

                if (childOERElement.getBlock() > 0)
                {
                    break;
                }

                ASN1Encodable child = seq.getObjectAt(t);

                if (childOERElement.getaSwitch() != null)
                {
                    childOERElement = childOERElement.getaSwitch().result(new SwitchIndexer.Asn1SequenceIndexer(seq));
                }

                if (isPresent(child, childOERElement))
                {
                    write(child, childOERElement);
                }
            }

            //
            // Extensions.
            //

            if (extensionDefined)
            {

                // Form presence bitmap 16.4.3
                int start = t;
                ByteArrayOutputStream presenceList = new ByteArrayOutputStream();
                j = 7;
                mask = 0;
                for (int i = start; i < childElements.size(); i++)
                {
                    if (j < 0)
                    {
                        presenceList.write(mask);
                        j = 7;
                        mask = 0;
                    }

                    if (i < seq.size() && isPresent(seq.getObjectAt(i), childElements.get(i)))
                    {
                        mask |= 1 << j;
                    }
                    j--;
                }

                // Write the final set of bits: at least one addition is present, so there is one.
                presenceList.write(mask);

                // 16.4.1: a length determinant covering the initial octet and the bitmap; 16.4.2: the
                // initial octet is the number of unused bits in the final octet - j is the next free
                // bit position in it, counting down from 7, so bits j to 0 are unused.
                int unusedBits = j + 1;
                encodeLength(presenceList.size() + 1);
                write(unusedBits);
                write(presenceList.toByteArray());

                // Open encode the actual values.
                for (; t < childElements.size(); t++)
                {
                    // 16.5.2 Extension Addition Groups are not supported.
                    if (t < seq.size() && isPresent(seq.getObjectAt(t), childElements.get(t)))
                    {
                        writePlainType(seq.getObjectAt(t), childElements.get(t));
                    }
                }
            }
            out.flush();
            debugPrint(oerElement.appendLabel(""));
        }
        break;
        case SEQ_OF:
            //
            // Assume this comes in as a sequence.
            //
            Enumeration e;
            if (encodable instanceof ASN1Set)
            {
                e = ((ASN1Set)encodable).getObjects();
                encodeQuantity(((ASN1Set)encodable).size());
            }
            else if (encodable instanceof ASN1Sequence)
            {
                e = ((ASN1Sequence)encodable).getObjects();
                encodeQuantity(((ASN1Sequence)encodable).size());
            }
            else
            {
                throw new IllegalStateException("encodable at for SEQ_OF is not a container");
            }


            Element encodingElement = Element.expandDeferredDefinition(oerElement.getFirstChid(), oerElement);

            while (e.hasMoreElements())
            {
                Object o = e.nextElement();
                write((ASN1Encodable)o, encodingElement);
            }
            out.flush();
            debugPrint(oerElement.appendLabel(""));
            break;
        case CHOICE:
        {
            ASN1Primitive item = encodable.toASN1Primitive();
            BitBuilder bb = new BitBuilder();
            int tag;

            ASN1Primitive valueToWrite = null;
            if (item instanceof ASN1TaggedObject)
            {
                ASN1TaggedObject taggedObject = (ASN1TaggedObject)item;

                //
                // Tag prefix.
                //
                int tagClass = taggedObject.getTagClass();
                bb.writeBit(tagClass & BERTags.CONTEXT_SPECIFIC)
                    .writeBit(tagClass & BERTags.APPLICATION);

                tag = taggedObject.getTagNo();
                valueToWrite = taggedObject.getBaseObject().toASN1Primitive();
            }
            else
            {
                throw new IllegalStateException("only support tagged objects");
            }

            //
            // Encode tag value.
            //

            // X.696 sec. 8.7.2.2: a tag number below 63 goes in bits 6 to 1 of the first octet;
            // 8.7.2.3: from 63 up those bits are all ones and the number follows in 7-bit groups
            if (tag < 63)
            {
                bb.writeBits(tag, 6);
            }
            else
            {
                bb.writeBits(0x3F, 6);
                bb.write7BitBytes(tag);
            }


            if (debugOutput != null)
            {
                if (item instanceof ASN1TaggedObject)
                {
                    ASN1TaggedObject taggedObject = (ASN1TaggedObject)item;
                    switch (taggedObject.getTagClass())
                    {
                    case BERTags.APPLICATION:
                        debugPrint(oerElement.appendLabel("AS"));
                        break;
                    case BERTags.CONTEXT_SPECIFIC:
                        debugPrint(oerElement.appendLabel("CS"));
                        break;
                    case BERTags.PRIVATE:
                        debugPrint(oerElement.appendLabel("PR"));
                        break;
                    }
                }
            }


            // Save the header.
            bb.writeAndClear(out);

            Element val = oerElement.getChildren().get(tag);
            val = Element.expandDeferredDefinition(val, oerElement);

            if (val.getBlock() > 0)
            {
                writePlainType(valueToWrite, val);
            }
            else
            {
                write(valueToWrite, val);
            }
            out.flush();
            break;
        }
        case ENUM:
        {
            BigInteger ordinal;
            if (encodable instanceof ASN1Integer)
            {
                ordinal = ASN1Integer.getInstance(encodable).getValue();
            }
            else
            {
                ordinal = ASN1Enumerated.getInstance(encodable).getValue();
            }

            for (Iterator it = oerElement.getChildren().iterator(); it.hasNext(); )
            {
                Element child = (Element)it.next();
                child = Element.expandDeferredDefinition(child, oerElement);

                //
                // This by default is canonical OER, see NOTE 1 and NOTE 2, 11.14
                // Section 11.4 of T-REC-X.696-201508-I!!PDF-E.pdf
                //
                if (child.getEnumValue().equals(ordinal))
                {
                    // X.696 sec. 11.4: the short form is for 0..127 only. A negative enumeration is a
                    // valid value and takes the long form, where toByteArray() gives its two's-complement.
                    if (ordinal.signum() < 0 || ordinal.bitLength() > 7)
                    {
                        // Note 2 Section 11.4 of T-REC-X.696-201508-I!!PDF-E.pdf
                        byte[] val = ordinal.toByteArray();
                        int l = 0x80 | (val.length & 0xFF);
                        out.write(l);
                        out.write(val);
                    }
                    else
                    {
                        out.write(ordinal.intValue() & 0x7F);
                    }
                    out.flush();
                    debugPrint(oerElement.appendLabel(oerElement.rangeExpression()));
                    return;
                }
            }

            // -DM Hex.toHexString
            throw new IllegalArgumentException("enum value " + ordinal + " " + Hex.toHexString(ordinal.toByteArray()) + " no in defined child list");
        }
        case INT:
        {
            BigInteger value = ASN1Integer.getInstance(encodable).getValue();

            // TODO Validate against bounds: beyond the sign, nothing below checks that value lies within
            // the element's effective value constraint.


            // >0 = positive and <0 = negative
            int intBytesForRange = oerElement.intBytesForRange();
            if (intBytesForRange > 0)
            {
                //
                // For unsigned fixed length 1,2,4,8 byte integers.
                //
                checkNonNegative(value, oerElement);
                byte[] encoded = BigIntegers.asUnsignedByteArray(intBytesForRange, value);
                switch (intBytesForRange)
                {
                case 1:
                case 2:
                case 4:
                case 8:
                    out.write(encoded);
                    break;
                default:
                    throw new IllegalStateException("unknown uint length " + intBytesForRange);
                }
            }
            else if (intBytesForRange < 0)
            {

                //
                // For twos compliment numbers of 1,2,4,8 bytes in encoded length.
                //

                byte[] encoded;
                switch (intBytesForRange)
                {
                case -1:
                    encoded = new byte[]{BigIntegers.byteValueExact(value)};
                    break;
                case -2:
                    encoded = Pack.shortToBigEndian(BigIntegers.shortValueExact(value));
                    break;
                case -4:
                    encoded = Pack.intToBigEndian(BigIntegers.intValueExact(value));
                    break;
                case -8:
                    encoded = Pack.longToBigEndian(BigIntegers.longValueExact(value));
                    break;
                default:
                    throw new IllegalStateException("unknown twos compliment length");
                }

                out.write(encoded);
            }
            else
            {
                // Unbounded at one or both ends and needs length encoding.
                byte[] encoded;
                if (oerElement.isLowerBoundNonNegative())
                {
                    // X.696 sec. 10.3 e): the fixed-width unsigned cases are handled above, so a lower
                    // bound of zero or more means a length determinant and a variable-size unsigned number.
                    checkNonNegative(value, oerElement);
                    encoded = BigIntegers.asUnsignedByteArray(value);
                }
                else
                {
                    // Twos complement
                    encoded = value.toByteArray();
                }

                encodeLength(encoded.length); // Deals with long and short forms.
                out.write(encoded);
            }
            debugPrint(oerElement.appendLabel(oerElement.rangeExpression()));
            out.flush();
        }

        break;
        case OCTET_STRING:
        {
            ASN1OctetString octets = ASN1OctetString.getInstance(encodable);
            byte[] bytes = octets.getOctets();
            if (oerElement.isFixedLength())
            {
                out.write(bytes);
            }
            else
            {
                encodeLength(bytes.length);
                out.write(bytes);
            }
            debugPrint(oerElement.appendLabel(oerElement.rangeExpression()));
            out.flush();
            break;
        }
        case IA5String:
        {
            ASN1IA5String iaf = ASN1IA5String.getInstance(encodable);
            byte[] encoded = iaf.getOctets();

            //
            // IA5Strings can be fixed length because they have a fixed multiplier.
            //
            if (oerElement.isFixedLength() && BigIntegers.intValueExact(oerElement.getUpperBound()) != encoded.length)
            {
                throw new IOException("IA5String string length does not equal declared fixed length "
                    + encoded.length + " " + oerElement.getUpperBound());
            }

            if (oerElement.isFixedLength())
            {
                out.write(encoded);
            }
            else
            {
                encodeLength(encoded.length);
                out.write(encoded);
            }
            debugPrint(oerElement.appendLabel(""));
            out.flush();
            break;
        }

        case UTF8_STRING:
        {
            ASN1UTF8String utf8 = ASN1UTF8String.getInstance(encodable);
            byte[] encoded = Strings.toUTF8ByteArray(utf8.getString());
            encodeLength(encoded.length);
            out.write(encoded);
            debugPrint(oerElement.appendLabel(""));
            out.flush();
            break;
        }
        case BIT_STRING:
        {
            ASN1BitString bitString = ASN1BitString.getInstance(encodable);
            byte[] bytes = bitString.getBytes();
            if (oerElement.isFixedLength())
            {
                out.write(bytes);
                debugPrint(oerElement.appendLabel(oerElement.rangeExpression()));
            }
            else
            {
                int padBits = bitString.getPadBits();
                encodeLength(bytes.length + 1); // 13.3.1
                out.write(padBits); // 13.3.2
                out.write(bytes); // 13.3.3
                debugPrint(oerElement.appendLabel(oerElement.rangeExpression()));
            }
            out.flush();
        }
        break;
        case NULL:
            // Does not encode in OER.
            break;
        case EXTENSION:
        {
            ASN1OctetString octets = ASN1OctetString.getInstance(encodable);
            byte[] bytes = octets.getOctets();
            if (oerElement.isFixedLength())
            {
                out.write(bytes);
            }
            else
            {
                encodeLength(bytes.length);
                out.write(bytes);
            }
            debugPrint(oerElement.appendLabel(oerElement.rangeExpression()));
            out.flush();
            break;
        }

        case ENUM_ITEM:
            // Used to define options does not encode.
            break;
        case BOOLEAN:
            debugPrint(oerElement.getLabel());
            ASN1Boolean asn1Boolean = ASN1Boolean.getInstance(encodable);
            if (asn1Boolean.isTrue())
            {
                out.write(255);
            }
            else
            {
                out.write(0);
            }
            out.flush();
        }

    }

    protected void debugPrint(String what)
    {

        if (debugOutput != null)
        {

            StackTraceElement[] callStack = Thread.currentThread().getStackTrace();
            int level = -1;
            for (int i = 0; i != callStack.length; i++)
            {
                StackTraceElement ste = callStack[i];
                if (ste.getMethodName().equals("debugPrint"))
                {
                    level = 0;
                    continue;
                }
                if (ste.getClassName().contains("OERInput"))
                {
                    level++;
                }
            }

            for (; level > 0; level--)
            {
                debugOutput.append("    ");
            }
            debugOutput.append(what).append("\n");
            debugOutput.flush();
        }
    }

    /**
     * A negative value is not in any type whose lower bound is zero or more, and the unsigned
     * encodings would silently write its two's-complement octets as a different, positive value
     * (-1 under INTEGER (0..255) came out as FF, the encoding of 255).
     */
    private static void checkNonNegative(BigInteger value, Element element)
    {
        if (value.signum() < 0)
        {
            throw new IllegalArgumentException("negative value " + value + " for INTEGER " + element.rangeExpression());
        }
    }

    private void encodeLength(long len)
        throws IOException
    {
        // every caller passes an array length or a collection size, so this is a guard against a
        // future mistake: a negative value would take the short form and go out as a single octet
        // with bit 8 set, which a decoder reads as a long-form prefix - silent corruption
        if (len < 0)
        {
            throw new IllegalArgumentException("negative length: " + len);
        }
        if (len <= 127) // complies with 31.2
        {
            out.write((int)len); // short form 8.6.3
        }
        else
        {
            // Long form, 8.6.5: bit 8 set and the octet count in the initial octet, then the length
            // as a variable-size unsigned number in the fewest octets (31.2)
            byte[] value = Longs.toUnsignedByteArray(len);
            out.write(value.length | 0x80);
            out.write(value);
        }
    }

    private void encodeQuantity(long quantity)
        throws IOException
    {
        if (quantity < 0)
        {
            throw new IllegalArgumentException("negative quantity: " + quantity);
        }
        // 17.2: the octet count, then the quantity as a variable-size unsigned number, which is one
        // or more octets (3.7.12) - so zero is 01 00, not the empty encoding the helper gives it
        byte[] quantityEncoded = quantity == 0 ? new byte[1] : Longs.toUnsignedByteArray(quantity);
        out.write(quantityEncoded.length);
        out.write(quantityEncoded);
    }

    public void write(int b)
        throws IOException
    {
        out.write(b);
    }


    public void writePlainType(ASN1Encodable value, Element e)
        throws IOException
    {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        OEROutputStream oerOutputStream = new OEROutputStream(bos);
        oerOutputStream.write(value, e);
        oerOutputStream.flush();
        oerOutputStream.close();

        encodeLength(bos.size());
        write(bos.toByteArray());
    }


}
